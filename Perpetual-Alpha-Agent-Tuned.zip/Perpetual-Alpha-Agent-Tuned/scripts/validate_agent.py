"""Network-free end-to-end functional acceptance of the agent, not an alpha benchmark."""
import json
import tempfile
from dataclasses import asdict
from pathlib import Path

from perpetual_alpha.agent.config import AgentConfig
from perpetual_alpha.agent.data import synthetic_observations
from perpetual_alpha.agent.harness import AgentHarness
from perpetual_alpha.agent.journal import AgentJournal
from perpetual_alpha.agent.replay import run_replay
from perpetual_alpha.agent.routing import RuleRouter


def main():
    config = AgentConfig(epsilon=0)
    binding = {"acceptance": "synthetic-functional-only", "config": asdict(config)}
    with tempfile.TemporaryDirectory() as directory:
        journal = AgentJournal(Path(directory)/"agent.sqlite3", binding)
        try:
            records, report = run_replay(synthetic_observations(), AgentHarness(config, RuleRouter(), journal))
            assert report["decisions"] == 360
            assert report["fills"] > 0
            assert report["daily_equity_return_stdev"] is None
            assert all(r["mode"] == "offline-paper" for r in records)
            assert all(f["filled_ms"] > f["created_ms"] for r in records for f in r["fills"])
            count = journal.db.execute("SELECT COUNT(*) FROM decisions").fetchone()[0]
            repeated, repeat_report = run_replay(synthetic_observations(), AgentHarness(config, RuleRouter(), journal))
            assert records == repeated and report == repeat_report
            assert journal.db.execute("SELECT COUNT(*) FROM decisions").fetchone()[0] == count
            print(json.dumps({"validation": "synthetic-functional-only", "report": report}, sort_keys=True))
        finally:
            journal.close()


if __name__ == "__main__":
    main()
