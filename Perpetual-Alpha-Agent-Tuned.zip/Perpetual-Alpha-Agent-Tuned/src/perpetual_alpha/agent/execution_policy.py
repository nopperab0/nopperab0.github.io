"""Cost-aware execution cadence and temporary mark-to-market exposure repair."""
import math


def breached(positions, market, config):
    notionals = {s: abs(p['quantity'])*market[s]['mid'] for s,p in positions.items() if s in market}
    return (sum(notionals.values()) > config.max_gross_usd+1e-8
            or any(n > config.max_asset_usd+1e-8 for n in notionals.values()))


def exposure_reductions(positions, market, config):
    if not breached(positions, market, config):
        return {}
    targets = {s: p['quantity']*market[s]['mid'] for s,p in positions.items() if s in market}
    capped = {s: math.copysign(min(abs(d), config.max_asset_usd*config.entry_headroom), d)
              for s,d in targets.items()}
    gross = sum(abs(d) for d in capped.values())
    scale = min(1, config.max_gross_usd*config.entry_headroom/gross) if gross else 1
    return {s: d*scale for s,d in capped.items() if d*scale != targets[s]}


def filter_targets(targets, positions, market, asof, config):
    capped = {s: math.copysign(min(abs(d), config.max_asset_usd*config.entry_headroom), d)
              for s,d in targets.items() if s in market}
    gross = sum(abs(d) for d in capped.values())
    scale = min(1, config.max_gross_usd*config.entry_headroom/gross) if gross else 1
    capped = {s: d*scale for s,d in capped.items()}
    result, rejected = {}, {}
    for s,d in capped.items():
        p = positions.get(s)
        if p is None:
            result[s] = d
            continue
        age = asof-p['opened_ms']
        if age < config.min_holding_minutes*60000:
            rejected[s] = 'minimum-holding-period'
        elif (p['quantity']*d > 0 and abs(d) > abs(p['quantity'])*market[s]['mid']
              and p.get('exit_ms', asof+config.min_holding_minutes*60000)-asof <
              config.min_holding_minutes*60000):
            rejected[s] = 'insufficient-holding-time-for-increase'
        elif asof-p.get('last_rebalanced_ms', p['opened_ms']) < config.rebalance_interval_minutes*60000:
            rejected[s] = 'rebalance-cadence'
        elif config.close_before_reverse and p['quantity']*d < 0:
            result[s] = 0.0
        elif (abs(d-p['quantity']*market[s]['mid']) <
              config.rebalance_fraction*abs(p['quantity'])*market[s]['mid']):
            rejected[s] = 'relative-rebalance-band'
        else:
            # Avoid creating residual holdings too small to close under the venue minimum.
            result[s] = 0.0 if 0 < abs(d) < config.min_order_usd else d
    return result, rejected
