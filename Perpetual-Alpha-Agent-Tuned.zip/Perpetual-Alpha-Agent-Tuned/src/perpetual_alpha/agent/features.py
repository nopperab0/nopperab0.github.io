"""Minute observations with explicit event/availability clocks and strict causal windows."""
import math
import statistics
from dataclasses import asdict, dataclass

from ..interfaces import timestamp
from ..venues import venue

MINUTE = 60000


def number(value, *, positive=False):
    if type(value) not in {str, int, float}:
        raise ValueError("Numeric value required")
    result = float(value)
    if not math.isfinite(result) or (positive and result <= 0):
        raise ValueError("Finite value required")
    return result


@dataclass(frozen=True)
class Observation:
    symbol: str
    asof_ms: int
    available_ms: int
    event_ms: int
    bid: float
    ask: float
    quantity_step: float
    oracle: float | None = None
    context_available_ms: int | None = None
    funding_rate: float | None = None
    funding_event_ms: int | None = None
    funding_available_ms: int | None = None

    def __post_init__(self):
        for key in ("asof_ms", "available_ms", "event_ms"):
            timestamp(getattr(self, key))
        venue(self.symbol.split(":", 1)[0]).validate_symbol(self.symbol)
        if not self.event_ms <= self.available_ms <= self.asof_ms:
            raise ValueError("Observation contains future information")
        for key in ("bid", "ask", "quantity_step"):
            object.__setattr__(self, key, number(getattr(self, key), positive=True))
        if self.ask < self.bid:
            raise ValueError("Crossed book")
        if (self.oracle is None) != (self.context_available_ms is None):
            raise ValueError("Oracle requires context receipt lineage")
        if self.oracle is not None:
            object.__setattr__(self, "oracle", number(self.oracle, positive=True))
            timestamp(self.context_available_ms)
            if self.context_available_ms > self.asof_ms:
                raise ValueError("Future context")
        values = (self.funding_rate, self.funding_event_ms, self.funding_available_ms)
        if any(v is not None for v in values):
            if any(v is None for v in values):
                raise ValueError("Funding requires event and receipt lineage")
            object.__setattr__(self, "funding_rate", number(self.funding_rate))
            timestamp(self.funding_event_ms)
            timestamp(self.funding_available_ms)
            if not self.funding_event_ms <= self.funding_available_ms <= self.asof_ms:
                raise ValueError("Future funding")

    @property
    def mid(self):
        return self.bid / 2 + self.ask / 2

    @property
    def spread_bps(self):
        return (self.ask - self.bid) / self.mid * 10000


def causal_window(rows, symbol, asof, config):
    """Missing/repeated/stale points break a window; never interpolate a price gap."""
    usable = [r for r in rows if r.asof_ms <= asof and r.available_ms <= asof]
    if any(r.symbol != symbol for r in rows):
        raise ValueError("Mixed observation symbol")
    if any(a.asof_ms >= b.asof_ms for a, b in zip(rows, rows[1:])):
        raise ValueError("Unordered or duplicate observations")
    if not usable or asof - usable[-1].asof_ms > config.max_age_ms:
        return []
    tail = []
    for row in reversed(usable[-config.history_minutes-1:]):
        if row.asof_ms - row.event_ms > config.max_age_ms:
            break
        if tail and (tail[-1].asof_ms-row.asof_ms != MINUTE or tail[-1].event_ms <= row.event_ms):
            break
        tail.append(row)
    return list(reversed(tail))


def build_features(histories, asof, config):
    timestamp(asof)
    output, failures = {}, {}
    for symbol, rows in sorted(histories.items()):
        venue(config.dex).validate_symbol(symbol)
        if symbol.endswith(":USDJPY"):
            failures[symbol] = "quote-currency-conversion-not-supplied"
            continue
        tail = causal_window(rows, symbol, asof, config)
        if len(tail) < 241 or asof-tail[-1].event_ms > config.max_age_ms:
            failures[symbol] = "need-241-contiguous-fresh-minute-observations"
            continue
        prices = [r.mid for r in tail]
        returns = [math.log(b/a) for a, b in zip(prices, prices[1:])]
        latest = tail[-1]
        if latest.spread_bps > config.max_spread_bps:
            failures[symbol] = "spread-limit"
            continue
        vol = max(statistics.stdev(returns[-120:])*10000, 1.0)
        mean = statistics.mean(prices[-61:-1])
        sd = statistics.stdev(prices[-61:-1])
        context_ok = (latest.oracle is not None and
                      asof-latest.context_available_ms <= config.max_age_ms)
        funding_ok = (latest.funding_rate is not None and
                      asof-latest.funding_event_ms <= 7200000 and
                      asof-latest.funding_available_ms <= 7200000)
        output[symbol] = {
            "symbol": symbol, "observed_ms": latest.asof_ms, "mid": latest.mid,
            "bid": latest.bid, "ask": latest.ask, "quantity_step": latest.quantity_step,
            "spread_bps": latest.spread_bps, "vol_bps": vol,
            "risk_bps": vol*math.sqrt(config.horizon_minutes),
            "momentum_15_bps": (prices[-1]/prices[-16]-1)*10000,
            "momentum_60_bps": (prices[-1]/prices[-61]-1)*10000,
            "momentum_240_bps": (prices[-1]/prices[-241]-1)*10000,
            "momentum_3_bps": (prices[-1]/prices[-4]-1)*10000,
            "momentum_1_bps": (prices[-1]/prices[-2]-1)*10000,
            "zscore": (prices[-1]-mean)/sd if sd else 0.0,
            "reversion_bps": (mean/prices[-1]-1)*10000,
            "basis_bps": (prices[-1]/latest.oracle-1)*10000 if context_ok else None,
            "oracle_change_bps": ((latest.oracle/tail[-2].oracle-1)*10000
                                  if context_ok and tail[-2].oracle is not None and
                                  asof-tail[-2].context_available_ms <= config.max_age_ms else None),
            "funding_rate": latest.funding_rate if funding_ok else None,
            "squeeze_ratio": (statistics.stdev(returns[-21:-1]) /
                              max(statistics.stdev(returns[-121:-21]), 1e-10)),
            "range_high": max(prices[-21:-1]), "range_low": min(prices[-21:-1]),
            "history": prices,
        }
    return output, failures


def public_features(features):
    return {s: {k: v for k, v in f.items() if k != "history"} for s, f in features.items()}


def snapshot_digest_input(histories, asof, config):
    return {s: [asdict(r) for r in rows if r.asof_ms <= asof][-config.history_minutes-1:]
            for s, rows in sorted(histories.items())}
