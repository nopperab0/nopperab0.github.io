"""Explicit local inputs and reuse of the repository's strict-as-of PAS panel."""
import csv
import json
import math
from collections import defaultdict
from contextlib import closing
from dataclasses import asdict
from pathlib import Path

from ..venues import venue
from .features import Observation


def aliases(path, protected):
    path = Path(path).resolve()
    return any(path == Path(p).resolve() or (path.exists() and Path(p).exists() and path.samefile(p))
               for p in protected)


def database_files(path):
    return [Path(str(path)+suffix) for suffix in ("", "-wal", "-shm", "-journal")]


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=no_duplicates,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Invalid JSON number")))


def load_snapshot(path):
    value = read_json(path)
    if not {"asof_ms", "histories"} <= set(value) <= {"asof_ms", "histories", "sentiment"}:
        raise ValueError("Snapshot needs asof_ms, histories and optional sentiment")
    return value["asof_ms"], {s: [Observation(**r) for r in rows]
                              for s, rows in value["histories"].items()}, value.get("sentiment")


def panel_observations(rows, quantity_steps, dex):
    """Reject invalid quotes, retain gaps, and never relabel PAR/PAS."""
    for r in rows:
        s = r["symbol"]
        venue(dex).validate_symbol(s)
        if r["source"] != venue(dex).source:
            raise ValueError("Panel source/venue mismatch")
        if str(r["quote_valid"]).lower() not in {"true", "1"}:
            continue
        if s not in quantity_steps:
            raise ValueError("Explicit quantity step required: " + s)
        oracle = r["oracle"] if str(r["context_valid"]).lower() in {"true", "1"} else None
        rate = r.get("funding_rate")
        yield Observation(s, int(r["decision_ms"]), int(r["book_available_ms"]), int(r["book_event_ms"]),
                          r["bid"], r["ask"], quantity_steps[s], oracle or None,
                          int(r["context_available_ms"]) if oracle else None,
                          rate if rate not in {None, ""} else None,
                          int(r["funding_event_ms"]) if rate not in {None, ""} else None,
                          int(r["funding_available_ms"]) if rate not in {None, ""} else None)


def read_panel_csv(path, quantity_steps, dex):
    with open(path, encoding="utf-8-sig", newline="") as stream:
        return list(panel_observations(csv.DictReader(stream), quantity_steps, dex))


def read_pas_db(path, start, end, quantity_steps):
    # Keep requests/collector dependencies out of fixture, captured and direct Jev CLI use.
    from ..pas_research import checked_derived, panel
    with closing(checked_derived(path)) as db:
        db.execute("BEGIN")
        return list(panel_observations(panel(db, start, end), quantity_steps, "pas"))


def synthetic_observations(minutes=360, dex="pas"):
    """Deterministic functional fixture; never a strategy-performance benchmark."""
    output = []
    base_ms = 1792368000000
    for i in range(minutes):
        for asset, base, step, phase in (("BTC", 60000, 0.00001, 0),
                                         ("ETH", 2500, 0.0001, 1), ("HYPE", 30, 0.01, 2)):
            drift = (0.00035 if i < 280 else -0.00045)*(1-phase*0.25)
            mid = base*math.exp(drift*i+0.003*math.sin(i/9+phase))
            asof = base_ms+i*60000
            output.append(Observation(f"{dex}:{asset}", asof, asof, asof, mid*0.9999, mid*1.0001, step,
                                      mid/1.008, asof, 0.0001, asof//3600000*3600000, asof))
    return output


def grouped(observations):
    groups = defaultdict(dict)
    for row in observations:
        if row.symbol in groups[row.asof_ms]:
            raise ValueError("Duplicate symbol/minute")
        groups[row.asof_ms][row.symbol] = row
    return sorted(groups.items())


def snapshot_json(observations):
    histories = defaultdict(list)
    for row in observations:
        histories[row.symbol].append(asdict(row))
    return {"asof_ms": max(r.asof_ms for r in observations), "histories": dict(histories)}
