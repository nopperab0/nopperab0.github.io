"""Minute-by-minute replay, common costs and report metrics for gate comparisons."""
import statistics
from collections import defaultdict


def summarize(records):
    if not records:
        raise ValueError("Nonempty replay required")
    peak, drawdown = records[0]["equity_mid"], 0.0
    daily, fills = {}, []
    for r in records:
        peak = max(peak, r["equity_mid"])
        drawdown = max(drawdown, 1-r["equity_mid"]/peak)
        daily[r["asof_ms"]//86400000] = r["equity_mid"]
        fills.extend(r["fills"])
    # Exclude partial UTC days from the daily-volatility estimate.
    first, last = records[0]["asof_ms"], records[-1]["asof_ms"]
    closes = [value for day, value in sorted(daily.items())
              if first <= day*86400000 and last >= (day+1)*86400000-60000]
    returns = [b/a-1 for a, b in zip(closes, closes[1:])]
    final = records[-1]
    return {"mode": "offline-paper", "decisions": len(records), "fills": len(fills),
            "net_return_mid": (final["equity_mid"]/records[0]["equity_mid"]-1
                               if final["valuation_complete"] else None),
            "equity_oracle_observed": final["equity_oracle_observed"],
            "max_drawdown_mid": drawdown,
            "daily_equity_return_stdev": statistics.stdev(returns) if len(returns) >= 2 else None,
            "daily_return_samples": len(returns), "fees": final["fees"], "funding": final["funding"],
            "turnover": final["turnover"], "exploration_fills": sum(f["exploratory"] for f in fills),
            "routing_errors": sum(r["routing"]["error"] not in {None, "no-eligible-proposals", 'routing-cadence',
                                                               'temporary-exposure-reduction'}
                                  for r in records),
            "open_positions": final["positions"], "unfilled_final_targets": final["pending_orders"],
            "funding_coverage_complete": final["funding_coverage_complete"],
            "valuation_complete": final["valuation_complete"], "funding_due": final["funding_due"],
            "limitations": ["Synthetic next-observation taker fills; no depth, queue or intraminute path",
                            "Oracle receipt freshness is not underlying oracle event freshness",
                            "No liquidation, live account margin, currency conversion or exchange reconciliation",
                            "No forced final liquidation; open holdings remain marked and disclosed",
                            "Unavailable funding settlements are not invented; inspect coverage separately"]}


def run_replay(observations, harness):
    from .data import grouped
    histories, records = defaultdict(list), []
    for asof, rows in grouped(observations):
        for symbol, row in rows.items():
            histories[symbol].append(row)
            histories[symbol] = histories[symbol][-harness.config.history_minutes-1:]
        records.append(harness.step(dict(histories), asof))
    return records, summarize(records)
