"""Original-mass risk sizing, asset netting and independent offline exposure checks."""
import math
from decimal import ROUND_DOWN, Decimal


def rounded(quantity, step):
    step = Decimal(str(step))
    return float((Decimal(str(quantity))/step).to_integral_value(rounding=ROUND_DOWN)*step)


def construct(proposals, selected, probabilities, features, config):
    contributions = []
    for strategy in selected:
        candidates = [p for p in proposals if p.strategy == strategy and p.eligible]
        if not candidates:
            continue
        # Each strategy sleeve has at most ONE portfolio budget across all its assets.
        # Each leg first scales down to a common holding-period volatility budget.
        unit = config.risk_budget_usd/len(candidates)
        for p in candidates:
            risk = max(v.risk_bps for v in candidates) if strategy == 'N03' else p.risk_bps
            dollars = (p.direction*unit*min(1, config.target_vol_bps/risk)*probabilities[strategy])
            contributions.append({"strategy": strategy, "symbol": p.symbol,
                                  "probability": probabilities[strategy], "notional_usd": dollars,
                                  "horizon_minutes": p.horizon_minutes})
    targets = {}
    for c in contributions:
        targets[c["symbol"]] = targets.get(c["symbol"], 0)+c["notional_usd"]
    pair = {c["symbol"] for c in contributions if c["strategy"] == "N03"}
    if len(pair) == 2 and math.prod(targets[s] for s in pair) >= 0:
        # Do not advertise a pair when netting cancels or flips one of its legs.
        for c in contributions:
            if c["strategy"] == "N03":
                targets[c["symbol"]] -= c["notional_usd"]
                c["notional_usd"] = 0.0
                c["suppressed_reason"] = "netted-rotation-would-be-one-sided"
        targets = {}
        for c in contributions:
            if c["notional_usd"]:
                targets[c["symbol"]] = targets.get(c["symbol"], 0)+c["notional_usd"]
    return targets, contributions


def review(targets, positions, features, config, *, halted=False, atomic_groups=()):
    quantities = {s: rounded(d/features[s]["mid"], features[s]["quantity_step"])
                  for s, d in targets.items() if s in features}
    for s in quantities:
        old = positions.get(s, {}).get("quantity", 0)
        if targets[s] == old*features[s]["mid"]:
            quantities[s] = old
    approved, reasons = review_quantities(quantities, positions, features, config, halted=halted,
                                          atomic_groups=atomic_groups)
    for s in targets.keys()-quantities.keys():
        reasons[s] = "missing-fresh-market"
    # A missing quote must also veto the other members of its basket.
    for members in atomic_groups:
        if any(s not in quantities for s in members):
            for s in members:
                approved.pop(s, None)
                reasons[s] = "atomic-basket-rejected"
    return approved, reasons


def review_quantities(targets, positions, features, config, *, halted=False, atomic_groups=()):
    """Recompute full gross, including retained holdings. Never increase risk to meet minimum size."""
    quantities, reasons = {}, {}
    unchanged = set()
    for symbol, target in sorted(targets.items()):
        f = features.get(symbol)
        if f is None:
            reasons[symbol] = "missing-fresh-market"
            continue
        current = positions.get(symbol, {}).get("quantity", 0)
        if not math.isfinite(target) or Decimal(str(target)) % Decimal(str(f["quantity_step"])):
            reasons[symbol] = "invalid-or-off-step-quantity"
            continue
        if target == current:
            unchanged.add(symbol)
            continue
        reducing = target*current >= 0 and abs(target) <= abs(current)
        if halted and not reducing:
            reasons[symbol] = "supervisor-halted"
            continue
        if not reducing and abs(target)*f["mid"] > config.max_asset_usd+1e-8:
            reasons[symbol] = "asset-limit"
            continue
        delta = abs(target-current)*f["mid"]
        if delta < config.min_order_usd or (not reducing and delta < config.rebalance_usd):
            reasons[symbol] = "below-minimum-or-rebalance-band"
            continue
        quantities[symbol] = target
    combined = {s: p["quantity"] for s, p in positions.items()}
    combined.update(quantities)
    # Missing quotes on retained positions block new exposure; exits remain permissible.
    unknown = any(s not in features and q != 0 for s, q in combined.items())
    gross = math.fsum(abs(q)*features[s]["mid"] for s, q in combined.items() if s in features)
    if unknown or gross > config.max_gross_usd+1e-8:
        for s, q in list(quantities.items()):
            old = positions.get(s, {}).get("quantity", 0)
            if not (old*q >= 0 and abs(q) <= abs(old)):
                del quantities[s]
                reasons[s] = "retained-position-unknown" if unknown else "portfolio-gross-limit"
    for members in atomic_groups:
        final = [targets.get(s, 0) for s in members]
        paired = all(q == 0 for q in final) or (all(q != 0 for q in final) and min(final) < 0 < max(final))
        if (len(set(members)) < 2 or not paired
                or any(s not in quantities and s not in unchanged for s in members)):
            for s in members:
                quantities.pop(s, None)
                reasons[s] = "atomic-basket-rejected"
        else:
            # An unchanged leg is fulfilled; keep its explicit target in the basket envelope.
            quantities.update({s: targets[s] for s in members if s in unchanged})
    # Rejecting a basket can retain positions that an earlier gross check assumed would close.
    # Recompute the final book and propagate any new veto until only a coherent safe subset remains.
    while True:
        removed = set()
        combined = {s: p["quantity"] for s, p in positions.items()}
        combined.update(quantities)
        unknown = any(s not in features and q != 0 for s, q in combined.items())
        gross = math.fsum(abs(q)*features[s]["mid"] for s, q in combined.items() if s in features)
        if unknown or gross > config.max_gross_usd+1e-8:
            for s, q in list(quantities.items()):
                old = positions.get(s, {}).get("quantity", 0)
                if not (old*q >= 0 and abs(q) <= abs(old)):
                    del quantities[s]
                    removed.add(s)
                    reasons[s] = "final-portfolio-gross-or-unknown-exposure"
        for members in atomic_groups:
            if any(s not in quantities for s in members):
                for s in members:
                    if s in quantities:
                        del quantities[s]
                        removed.add(s)
                        reasons[s] = "atomic-basket-rejected"
        if not removed:
            break
    return quantities, reasons


def basket_groups(contributions, positions, targets):
    """Connect overlapping pair dependencies, including already open pair lifecycles."""
    groups = [set(p.get("basket_members", ())) for p in positions.values() if p.get("basket_members")]
    rotation = {c["symbol"] for c in contributions if c["strategy"] == "N03" and c["notional_usd"]}
    if rotation:
        groups.append(rotation)
    merged = []
    for group in groups:
        for previous in list(merged):
            if group & previous:
                group |= previous
                merged.remove(previous)
        if len(group) >= 2:
            merged.append(group)
    return [tuple(sorted(g)) for g in merged if g & targets.keys()]
