"""Atomic offline state + decision log. Restart cannot reset exploration budgets."""
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from ..journal import canonical, digest

APP_ID = 0x41475631


class AgentJournal:
    def __init__(self, path, identity):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, timeout=15)
        try:
            with self.db:
                self.db.execute("BEGIN IMMEDIATE")
                tables = self.db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
                if not tables:
                    self.db.execute(f"PRAGMA application_id={APP_ID}")
                    self.db.execute("CREATE TABLE identity (payload TEXT NOT NULL)")
                    self.db.execute("CREATE TABLE policy (payload TEXT NOT NULL)")
                    self.db.execute("CREATE TABLE state (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL)")
                    self.db.execute("CREATE TABLE decisions (asof_ms INTEGER PRIMARY KEY, input_hash TEXT NOT NULL, "
                                    "payload TEXT NOT NULL)")
                    self.db.execute("CREATE TABLE observations (symbol TEXT, asof_ms INTEGER, hash TEXT, payload TEXT, "
                                    "PRIMARY KEY(symbol,asof_ms))")
                    self.db.execute("INSERT INTO identity VALUES(?)", (canonical(identity),))
                if self.db.execute("PRAGMA application_id").fetchone()[0] != APP_ID:
                    raise ValueError("Foreign journal; use an agent-only output path")
                if self.db.execute("SELECT payload FROM identity").fetchone()[0] != canonical(identity):
                    raise ValueError("Journal config/router/run binding changed; use a new journal")
        except BaseException:
            self.db.close()
            raise

    @contextmanager
    def transaction(self):
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            yield

    def state(self, initial):
        row = self.db.execute("SELECT payload FROM state WHERE id=1").fetchone()
        return json.loads(row[0]) if row else initial

    def bind_policy(self, policy):
        with self.transaction():
            rows = self.db.execute("SELECT payload FROM policy").fetchall()
            if rows and rows[0][0] != canonical(policy):
                raise ValueError("Harness policy/model/equity changed; use a new journal")
            if not rows:
                self.db.execute("INSERT INTO policy VALUES(?)", (canonical(policy),))

    def cached(self, asof, input_hash):
        row = self.db.execute("SELECT input_hash,payload FROM decisions WHERE asof_ms=?", (asof,)).fetchone()
        if row:
            if row[0] != input_hash:
                raise ValueError("Conflicting input for committed decision time")
            return json.loads(row[1])

    def save(self, asof, input_hash, record, state):
        record["record_digest"] = digest(record)
        self.db.execute("INSERT INTO decisions VALUES(?,?,?)", (asof, input_hash, canonical(record)))
        self.db.execute("INSERT OR REPLACE INTO state VALUES(1,?)", (canonical(state),))

    def freeze(self, snapshot):
        refs = {}
        for symbol, rows in snapshot.items():
            for row in rows:
                payload, hashed = canonical(row), digest(row)
                existing = self.db.execute("SELECT hash FROM observations WHERE symbol=? AND asof_ms=?",
                                           (symbol, row["asof_ms"])).fetchone()
                if existing and existing[0] != hashed:
                    raise ValueError("Historical observation changed inside a frozen run")
                if not existing:
                    self.db.execute("INSERT INTO observations VALUES(?,?,?,?)",
                                    (symbol, row["asof_ms"], hashed, payload))
            refs[symbol] = {"count": len(rows), "first_ms": rows[0]["asof_ms"] if rows else None,
                            "last_ms": rows[-1]["asof_ms"] if rows else None, "digest": digest(rows)}
        return refs

    def close(self):
        self.db.close()
