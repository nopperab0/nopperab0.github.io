"""Read-only strategy agent and offline paper research. No signing capability."""

VERSION = "agent/1.1"
