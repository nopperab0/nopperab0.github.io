"""Local agent demo/request/decide/replay. No exchange credentials or execution command."""
import argparse
import hashlib
import json
from dataclasses import asdict
from pathlib import Path

from ..journal import canonical, digest
from . import VERSION
from .config import AgentConfig, load_config
from .data import (
    aliases,
    database_files,
    load_snapshot,
    read_json,
    read_panel_csv,
    read_pas_db,
    snapshot_json,
    synthetic_observations,
)
from .features import build_features, public_features, snapshot_digest_input
from .harness import AgentHarness, checked_sentiment
from .journal import AgentJournal
from .replay import run_replay
from .routing import JevRouter, RuleRouter, make_request
from .strategies import generate


def router_for(args):
    if args.router == "rules":
        return RuleRouter()
    if args.router == "jev":
        from .jev_api import load_config, request_choice
        config = load_config(args.jev_env) if args.jev_env else load_config()
        if args.model_version and args.model_version != config.model:
            raise ValueError("CLI model version must match JEV_MODEL in your local configuration")
        return JevRouter(lambda request: request_choice(request, config=config), config.model)
    if not args.model_version:
        raise ValueError("Pin --model-version for captured responses")
    responses = read_json(args.responses)
    if isinstance(responses, dict) and "request_id" in responses:
        responses = {responses["request_id"]: responses}
    return JevRouter(lambda request: responses[request["request_id"]], args.model_version)


def write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("fixture", "demo", "request", "decide", "replay"))
    parser.add_argument("--config")
    parser.add_argument("--out", required=True)
    parser.add_argument("--journal")
    parser.add_argument("--snapshot")
    parser.add_argument("--panel-csv")
    parser.add_argument("--derived-db")
    parser.add_argument("--metadata", help="JSON symbol -> quantity step from the selected venue metadata")
    parser.add_argument("--start-ms", type=int)
    parser.add_argument("--end-ms", type=int)
    parser.add_argument("--router", choices=("rules", "captured", "jev"), default="rules")
    parser.add_argument("--responses")
    parser.add_argument("--model-version")
    parser.add_argument("--jev-env", help="Local Jev configuration file (default: repository .env.jev)")
    args = parser.parse_args(argv)
    protected = [p for p in (args.snapshot, args.panel_csv, args.derived_db, args.metadata,
                             args.config, args.responses, args.jev_env) if p]
    from .jev_api import ENV_FILE
    protected.append(str(ENV_FILE))
    if args.journal:
        if aliases(args.journal, [item for p in protected for item in database_files(p)]):
            raise ValueError("Journal must differ from all input paths")
        protected.append(args.journal)
    if aliases(args.out, [item for p in protected for item in database_files(p)]):
        raise ValueError("Output must differ from inputs/journal")
    config = load_config(args.config) if args.config else AgentConfig()
    if args.command == "fixture":
        write_json(args.out, snapshot_json(synthetic_observations(250, config.dex)))
        print(canonical({"kind": "synthetic-only-snapshot", "out": args.out}))
        return
    if args.command in {"request", "decide"}:
        if not args.snapshot:
            parser.error("--snapshot required")
        asof, histories, sentiment = load_snapshot(args.snapshot)
        if args.command == "request":
            f, _ = build_features(histories, asof, config)
            factor = checked_sentiment(sentiment, asof)
            cutoff = digest({"snapshot": snapshot_digest_input(histories, asof, config),
                             "sentiment": factor, "asof_ms": asof})
            request = make_request(asof, public_features(f), generate(f, config), cutoff, factor)
            write_json(args.out, request)
            print(canonical({"request_id": request["request_id"], "out": args.out}))
            return
    elif args.command == "demo":
        observations = synthetic_observations(dex=config.dex)
    else:
        if bool(args.panel_csv) == bool(args.derived_db) or not args.metadata:
            parser.error("Choose --panel-csv OR --derived-db, and supply --metadata")
        metadata = read_json(args.metadata)
        if args.panel_csv:
            observations = read_panel_csv(args.panel_csv, metadata, config.dex)
        else:
            if config.dex != "pas" or args.start_ms is None or args.end_ms is None:
                parser.error("Derived DB requires pas config and --start-ms/--end-ms")
            observations = read_pas_db(args.derived_db, args.start_ms, args.end_ms, metadata)
    if not args.journal:
        parser.error("--journal required for durable decisions")
    if args.router == "captured" and not args.responses:
        parser.error("--responses required for captured router")
    router = router_for(args)
    # Online-style decide calls bind each snapshot in its record, allowing later snapshots in the same journal.
    source_paths = [p for p in (args.panel_csv, args.metadata, args.responses) if p] if args.command == "replay" else []
    identity = {"schema": VERSION, "config": asdict(config), "model": router.model_version,
                "command": args.command, "source_hashes": {
                    str(Path(p).resolve()): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in source_paths},
                "derived_db": str(Path(args.derived_db).resolve()) if args.derived_db else None,
                "start_ms": args.start_ms, "end_ms": args.end_ms, "initial_equity": 100000.0}
    journal = AgentJournal(args.journal, identity)
    try:
        harness = AgentHarness(config, router, journal)
        if args.command == "decide":
            result = harness.step(histories, asof, sentiment=sentiment)
            write_json(args.out, result)
            print(canonical({"routing": result["routing"], "out": args.out}))
        else:
            _, report = run_replay(observations, harness)
            write_json(args.out, {"identity": identity, "report": report})
            print(canonical(report))
    finally:
        journal.close()


if __name__ == "__main__":
    main()
