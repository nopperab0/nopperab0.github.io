"""Explicit research parameters; none authorize exchange execution."""
import math
import tomllib
from dataclasses import asdict, dataclass, field


@dataclass(frozen=True)
class AgentConfig:
    dex: str = "pas"
    top_p: float = 0.85
    gate: str = "top_p"
    top_k: int = 2
    epsilon: float = 0.02
    seed: int = 20261021
    horizon_minutes: int = 60
    strategy_horizon_minutes: dict[str, int] = field(default_factory=dict)
    history_minutes: int = 1440
    max_age_ms: int = 90000
    max_inference_ms: int = 2000
    max_spread_bps: float = 30.0
    taker_fee_bps: float = 9.0
    slippage_bps: float = 2.0
    min_net_edge_bps: float = 5.0
    risk_budget_usd: float = 1000.0
    target_vol_bps: float = 50.0
    max_asset_usd: float = 500.0
    max_gross_usd: float = 1000.0
    min_order_usd: float = 10.0
    rebalance_usd: float = 20.0
    exploration_usd: float = 50.0
    exploration_cooldown_ms: int = 3600000
    exploration_max_daily: int = 2
    max_drawdown: float = 0.03
    stop_loss_bps: float = 150.0
    take_profit_bps: float = 300.0
    routing_interval_minutes: int = 1
    min_holding_minutes: int = 0
    rebalance_interval_minutes: int = 0
    rebalance_fraction: float = 0.0
    min_trade_mass: float = 0.0
    no_trade_veto: float = 1.0
    entry_headroom: float = 0.95
    close_before_reverse: bool = False
    entry_cooldown_minutes: int = 0
    breakout_distance_vol: float = 0.25
    momentum_confirmation: bool = True
    trend_240_confirmation: bool = False
    trend_entry_mode: str = 'momentum'
    range_240_filter: bool = False
    exit_on_trend_break: bool = False

    def __post_init__(self):
        if self.dex not in {"par", "pas"} or self.gate not in {"top_p", "top_k", "all"}:
            raise ValueError("Explicit venue and supported gate required")
        for key, value in asdict(self).items():
            if key in {"dex", "gate", "strategy_horizon_minutes", "close_before_reverse", "momentum_confirmation",
                       "trend_240_confirmation", 'trend_entry_mode', 'range_240_filter', 'exit_on_trend_break'}:
                continue
            if type(value) not in {float, int} or not math.isfinite(value) or value < 0:
                raise ValueError("Invalid configuration: " + key)
        for key in ("top_k", "seed", "horizon_minutes", "history_minutes", "max_age_ms", "max_inference_ms",
                    "exploration_cooldown_ms", "exploration_max_daily", "routing_interval_minutes",
                    "min_holding_minutes", "rebalance_interval_minutes", "entry_cooldown_minutes"):
            if type(getattr(self, key)) is not int:
                raise ValueError("Integer configuration required: " + key)
        if not 0 < self.top_p <= 1 or not 0 <= self.epsilon <= 1 or not 0 < self.max_drawdown < 1:
            raise ValueError("Invalid probability or drawdown")
        if not 1 <= self.top_k <= 9 or not 1 <= self.horizon_minutes <= 240:
            raise ValueError("Invalid gate size or horizon")
        if (self.history_minutes < max(240, self.horizon_minutes) or self.max_age_ms <= 0
                or not 0 < self.max_inference_ms <= self.max_age_ms):
            raise ValueError("Insufficient history window or TTL")
        if any(getattr(self, k) <= 0 for k in ("risk_budget_usd", "target_vol_bps", "max_asset_usd",
                                             "max_gross_usd", "min_order_usd", "stop_loss_bps")):
            raise ValueError("Positive risk bounds required")
        if self.exploration_usd > self.max_gross_usd or self.min_order_usd < 10:
            raise ValueError("Invalid exploration or venue minimum")
        if (not 1 <= self.routing_interval_minutes <= 60 or not 0 < self.entry_headroom < 1
                or not 0 <= self.rebalance_fraction <= 1 or not 0 <= self.min_trade_mass <= 1
                or not 0 <= self.no_trade_veto <= 1 or type(self.close_before_reverse) is not bool
                or type(self.momentum_confirmation) is not bool or type(self.trend_240_confirmation) is not bool):
            raise ValueError("Invalid execution cadence or probability filters")
        if self.trend_entry_mode not in {'momentum', 'pullback'}:
            raise ValueError('Unsupported trend entry mode')
        if type(self.range_240_filter) is not bool or type(self.exit_on_trend_break) is not bool:
            raise ValueError('Boolean regime/exit controls required')
        from .strategies import CATALOG
        if (not isinstance(self.strategy_horizon_minutes, dict)
                or not set(self.strategy_horizon_minutes) <= set(CATALOG)
                or any(type(h) is not int or not 1 <= h <= min(240, self.history_minutes)
                       for h in self.strategy_horizon_minutes.values())):
            raise ValueError("Invalid per-strategy holding periods")

    def horizon_for(self, strategy):
        return self.strategy_horizon_minutes.get(strategy, self.horizon_minutes)


def load_config(path):
    with open(path, "rb") as stream:
        payload = tomllib.load(stream)
    if set(payload) != {"agent"}:
        raise ValueError("Expected one [agent] section")
    return AgentConfig(**payload["agent"])
