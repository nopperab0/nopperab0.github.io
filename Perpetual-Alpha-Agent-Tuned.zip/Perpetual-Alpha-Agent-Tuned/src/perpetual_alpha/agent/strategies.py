"""Eight deterministic action policies. Edge estimates are hypotheses, not calibrated forecasts."""
import math
from dataclasses import asdict, dataclass

CATALOG = {
    "S02": "Multi-horizon trend: aligned 15m/60m momentum",
    "S03": "Range mean reversion: deviation with weak 60m trend",
    "S04": "Single-leg local-mid/oracle basis convergence; no hedge",
    "S14": "Directional funding carry with price-risk charge; no hedge",
    "N01": "Volatility compression followed by a 20m range break",
    "N02": "Extreme 15m move with observed 3m reversal confirmation",
    "N03": "Risk-adjusted relative strength within BTC/ETH/HYPE",
    "N04": "Observed oracle repricing continuation; no fabricated calendar event",
}
OPTIONS = (*CATALOG, "NO_TRADE")


@dataclass(frozen=True)
class Proposal:
    strategy: str
    symbol: str
    direction: int
    gross_edge_bps: float
    cost_bps: float
    risk_bps: float
    optimistic_net_bps: float | None
    scenario_samples: int
    eligible: bool
    reason: str
    horizon_minutes: int = 60

    @property
    def net_edge_bps(self):
        return self.gross_edge_bps-self.cost_bps

    def to_dict(self):
        return {**asdict(self), "net_edge_bps": self.net_edge_bps,
                "edge_model": "heuristic-signal-proxy/1", "edge_calibrated": False,
                "funding_is_historical": self.strategy == "S14"}


def sign(value):
    return 1 if value > 0 else -1 if value < 0 else 0


def scenario(prices, direction, config, cost, *, horizon_minutes=None):
    """Past, nonoverlapping holding-period returns; empirical upper scenario, not a future q90."""
    h = config.horizon_minutes if horizon_minutes is None else horizon_minutes
    points = list(reversed(prices[::-h]))
    returns = sorted(direction*(b/a-1)*10000-cost for a, b in zip(points, points[1:]))
    if len(returns) < 20:
        return None, len(returns)
    return returns[math.ceil(0.9*len(returns))-1], len(returns)


def generate(features, config):
    proposals = []
    crypto = [f for s, f in features.items() if s.split(":")[1] in {"BTC", "ETH", "HYPE"}]
    def relative_score(f):
        return f["momentum_60_bps"]/(f["vol_bps"]*math.sqrt(config.horizon_for("N03")))
    ranks = sorted(crypto, key=lambda f: (relative_score(f), f["symbol"]))
    rotation, relative_edge = {}, 0.0
    if len(ranks) == 3:
        spread = relative_score(ranks[-1])-relative_score(ranks[0])
        if spread > 1:
            rotation = {ranks[-1]["symbol"]: 1, ranks[0]["symbol"]: -1}
            # Equal-dollar pair return is half the momentum difference. Discount
            # continuation by 50%; do not add two absolute directional moves.
            relative_edge = max(0, ranks[-1]['momentum_60_bps']-ranks[0]['momentum_60_bps'])*0.25
    for symbol, f in sorted(features.items()):
        m15, m60, m3 = (f[k] for k in ("momentum_15_bps", "momentum_60_bps", "momentum_3_bps"))
        vol, risk = f["vol_bps"], f["risk_bps"]
        funding = f["funding_rate"]
        for strategy in CATALOG:
            horizon = config.horizon_for(strategy)
            risk = vol*math.sqrt(horizon)
            direction, edge = 0, 0.0
            if strategy == "S02" and m15*m60 > 0 and abs(m60) > risk:
                direction, edge = sign(m60), abs(m60)*0.5
                if config.trend_entry_mode == 'pullback':
                    if m3*m60 >= 0 or f['momentum_1_bps']*m60 <= 0:
                        direction = 0
                elif config.momentum_confirmation and m3*m60 <= 0:
                    direction = 0
                if config.trend_240_confirmation and f['momentum_240_bps']*m60 <= 0:
                    direction = 0
            elif strategy == "S03" and abs(f["zscore"]) >= 1.5 and abs(m60) < risk:
                direction, edge = sign(f["reversion_bps"]), abs(f["reversion_bps"])*0.5
                if config.range_240_filter and abs(f['momentum_240_bps']) >= vol*math.sqrt(240):
                    direction = 0
            elif strategy == "S04" and f["basis_bps"] is not None:
                direction, edge = -sign(f["basis_bps"]), abs(f["basis_bps"])*0.5
            elif strategy == "S14" and funding is not None:
                direction = -sign(funding)
                edge = abs(funding)*10000*horizon/60-risk*0.5
            elif strategy == "N01" and f["squeeze_ratio"] < 0.7:
                if f["mid"] > f["range_high"] or f["mid"] < f["range_low"]:
                    direction = 1 if f["mid"] > f["range_high"] else -1
                    boundary = f["range_high"] if direction > 0 else f["range_low"]
                    distance = abs(f["mid"]/boundary-1)*10000
                    # Volatility is risk, not an expected profit estimate.
                    edge = abs(m15)*0.5
                    if (distance < config.breakout_distance_vol*vol or m15*direction <= 0
                            or (config.momentum_confirmation and m3*direction <= 0)):
                        direction = 0
                    if config.trend_240_confirmation and f['momentum_240_bps']*direction <= 0:
                        direction = 0
            elif strategy == "N02" and abs(m15) > 3*vol*math.sqrt(15) and m15*m3 < 0:
                direction, edge = -sign(m15), abs(m15)*0.5
            elif strategy == "N03" and symbol in rotation:
                direction, edge = rotation[symbol], relative_edge
            elif strategy == "N04" and f["oracle_change_bps"] is not None:
                change = f["oracle_change_bps"]
                if abs(change) > max(20, 3*vol) and change*m3 > 0:
                    direction, edge = sign(change), abs(change)*0.5
            adverse_funding = (max(0, direction*funding)*10000*horizon/60
                               if funding is not None and strategy != "S14" else 0)
            cost = 2*config.taker_fee_bps+2*config.slippage_bps+f["spread_bps"]+adverse_funding
            upper, count = (scenario(f["history"], direction, config, cost, horizon_minutes=horizon)
                            if direction else (None, 0))
            eligible = bool(direction and edge-cost >= config.min_net_edge_bps)
            proposals.append(Proposal(strategy, symbol, direction, edge, cost, risk, upper, count,
                                      eligible, "eligible" if eligible else "no-signal-or-net-edge-below-cost",
                                      horizon))
    # Rotation is a two-leg hypothesis; never silently keep just the cheap/available leg.
    pair = [p for p in proposals if p.strategy == "N03" and p.eligible]
    if len(pair) != 2:
        proposals = [Proposal(**{**asdict(p), "eligible": False, "reason": "rotation-needs-both-legs"})
                     if p.strategy == "N03" else p for p in proposals]
    return proposals
