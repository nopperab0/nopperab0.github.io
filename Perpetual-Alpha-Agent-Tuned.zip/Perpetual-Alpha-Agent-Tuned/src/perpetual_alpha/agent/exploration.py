"""Persistent opportunity-level optimistic exploration, independent of Choice weights."""
from ..journal import digest

DAY = 86400000


def choose(proposals, asof, state, config):
    eligible = [p for p in proposals if p.eligible and p.optimistic_net_bps is not None
                and p.optimistic_net_bps > 0 and p.strategy != "N03"]
    if not eligible or config.epsilon == 0 or config.exploration_usd < config.min_order_usd:
        return None, {"status": "disabled-or-no-qualified-upper-scenario"}
    # Rank upside per unit of ex ante volatility; raw high-volatility assets do not win by construction.
    best = max(eligible, key=lambda p: (p.optimistic_net_bps/p.risk_bps, p.strategy, p.symbol))
    opportunity = digest({"bucket": asof//(best.horizon_minutes*60000),
                          "strategy": best.strategy, "symbol": best.symbol, "direction": best.direction})
    day = asof//DAY
    if state.get("day") != day:
        state.update(day=day, attempts=0, seen=[])
    if (opportunity in state["seen"] or state["attempts"] >= config.exploration_max_daily
            or asof-state.get("last_attempt_ms", -10**18) < config.exploration_cooldown_ms):
        return None, {"status": "opportunity-budget-or-cooldown", "opportunity_id": opportunity}
    # Consumes an opportunity even when the coin flip says no. Durable before the next cycle.
    state["seen"].append(opportunity)
    draw = int(digest({"seed": config.seed, "opportunity": opportunity})[:13], 16)/16**13
    selected = draw < config.epsilon
    if selected:
        state["attempts"] += 1
        state["last_attempt_ms"] = asof
    return best if selected else None, {
        "status": "selected" if selected else "normal", "opportunity_id": opportunity,
        "draw": draw, "epsilon": config.epsilon, "candidate": best.to_dict(),
        "ranking": "past-upper-net-scenario / holding-period-volatility",
    }
