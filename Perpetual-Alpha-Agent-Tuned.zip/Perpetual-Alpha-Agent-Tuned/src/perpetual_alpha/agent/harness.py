"""Frozen-snapshot agent cycle; exits continue when the router is unavailable."""
import copy
import time
from dataclasses import asdict

from ..journal import digest
from . import VERSION
from .execution_policy import breached, exposure_reductions, filter_targets
from .exploration import choose
from .features import build_features, number, public_features, snapshot_digest_input
from .paper import exits, fill_pending, initial_state, mark_and_fund, market_at, oracle_equity
from .portfolio import basket_groups, construct, review
from .routing import gate, make_request, validate_response
from .strategies import generate


def checked_sentiment(payload, asof):
    """Optional external structured factor; no news scraping or hidden LLM call."""
    if payload is None:
        return None
    if set(payload) != {"available_ms", "expires_ms", "score", "source_id"}:
        raise ValueError("Invalid sentiment factor")
    if (type(payload["available_ms"]) is not int or type(payload["expires_ms"]) is not int
            or not 0 <= payload["available_ms"] <= asof < payload["expires_ms"]
            or not isinstance(payload["source_id"], str) or not payload["source_id"]
            or not -1 <= number(payload["score"]) <= 1):
        raise ValueError("Stale/future/invalid sentiment")
    return copy.deepcopy(payload)


class AgentHarness:
    def __init__(self, config, router, journal, *, initial_equity=100000.0):
        self.config, self.router, self.journal = copy.deepcopy(config), router, journal
        self.model_version = router.model_version
        self.initial_equity = number(initial_equity, positive=True)
        journal.bind_policy({"version": VERSION, "config": asdict(config), "model": router.model_version,
                             "initial_equity": self.initial_equity})

    def step(self, histories, asof, *, sentiment=None):
        config = self.config
        # Invalid snapshot fails before mutating the journal. Future rows are excluded from the snapshot hash.
        features, failures = build_features(histories, asof, config)
        snapshot = snapshot_digest_input(histories, asof, config)
        histories = {s: [r for r in rows if r.asof_ms <= asof][-config.history_minutes-1:]
                     for s, rows in histories.items()}
        factor, factor_error = None, None
        try:
            factor = checked_sentiment(sentiment, asof)
        except (ValueError, TypeError):
            factor_error = "invalid-or-stale-sentiment"
        input_hash = digest({"snapshot": snapshot, "sentiment": factor if not factor_error else factor_error,
                             "asof_ms": asof})
        with self.journal.transaction():
            cached = self.journal.cached(asof, input_hash)
            if cached is not None:
                return cached
            state = self.journal.state(initial_state(self.initial_equity))
            if asof <= state["last_ms"]:
                raise ValueError("New decision time must advance the durable watermark")
            snapshot_refs = self.journal.freeze(snapshot)
            market = market_at(histories, asof, config)
            ledger_events = mark_and_fund(state, histories, market, asof)
            if state["cash"] <= state["peak_equity"]*(1-config.max_drawdown):
                state["halted"] = True
            # Mark drift blocks increases and schedules a reduction, not a permanent halt.
            exposure_breach = breached(state['positions'], market, config)
            if exposure_breach:
                state['pending'] = {}
            fills, execution_rejections = fill_pending(state, market, asof, config)
            if state["cash"] <= state["peak_equity"]*(1-config.max_drawdown):
                state["halted"] = True
            exit_targets, exit_reasons = exits(state, market, asof, config, features=features)
            risk_targets = exposure_reductions(state['positions'], market, config)
            proposals = generate(features, config)
            request = make_request(asof, public_features(features), proposals, input_hash, factor)
            response, probabilities, selected, cumulative = None, {}, [], 0.0
            routing_error, latency_ms = None, 0.0
            identity_error = self.router.model_version != self.model_version
            route_due = asof % (config.routing_interval_minutes*60000) == 0
            if (not identity_error and not factor_error and not state["halted"] and route_due
                    and not exposure_breach and any(p.eligible for p in proposals)):
                start = time.monotonic()
                try:
                    response = self.router.route(copy.deepcopy(request))
                    probabilities = validate_response(response, request, self.model_version)
                    selected, cumulative = gate(probabilities, config)
                except Exception as error:
                    # Do not log transport exception text: it can contain credentials/headers.
                    routing_error = type(error).__name__
                latency_ms = (time.monotonic()-start)*1000
                if not routing_error and latency_ms > config.max_inference_ms:
                    routing_error = "inference-time-budget"
                    probabilities, selected, cumulative = {}, [], 0.0
            elif factor_error:
                routing_error = factor_error
            elif identity_error:
                routing_error = "router-identity-changed"
            elif state["halted"]:
                routing_error = "supervisor-halted"
            elif exposure_breach:
                routing_error = 'temporary-exposure-reduction'
            elif not route_due:
                routing_error = 'routing-cadence'
            else:
                routing_error = "no-eligible-proposals"
            targets, contributions = construct(proposals, selected, probabilities, features, config)
            trade_mass = sum(probabilities[k] for k in selected if k != 'NO_TRADE')
            execution_gate = None
            if probabilities and (trade_mass < config.min_trade_mass or
                                  probabilities.get('NO_TRADE', 0) >= config.no_trade_veto):
                targets, contributions = {}, []
                execution_gate = 'insufficient-active-mass-or-no-trade-veto'
            exploration = {"status": "not-attempted"}
            exploratory = set()
            # A successful NO_TRADE-only gate is a veto on exploration for this cycle.
            has_exploration = any(p["exploratory"] for p in state["positions"].values())
            if probabilities and targets and not has_exploration:
                explore_candidates = [p for p in proposals if p.symbol not in state["positions"]
                                      and asof >= state["cooldowns"].get(p.symbol, 0)]
                candidate, exploration = choose(explore_candidates, asof, state["exploration"], config)
                if candidate:
                    # Exploration replaces the normal new target for this cycle, not an extra unbounded sleeve.
                    targets = {candidate.symbol: candidate.direction*config.exploration_usd*
                               min(1, config.target_vol_bps/candidate.risk_bps)}
                    contributions = []
                    exploratory.add(candidate.symbol)
            targets = {s: v for s, v in targets.items() if asof >= state["cooldowns"].get(s, 0)
                       and not state["positions"].get(s, {}).get("exploratory", False)}
            targets, execution_filters = filter_targets(targets, state['positions'], market, asof, config)
            if exposure_breach:
                targets = {}
            targets.update(risk_targets)
            targets.update(exit_targets)
            groups = basket_groups(contributions, state["positions"], targets)
            new_pair = {c["symbol"] for c in contributions if c["strategy"] == "N03" and c["notional_usd"]}
            for members in groups:
                for s in members:
                    if s not in targets and s in market and s not in new_pair:
                        targets[s] = state["positions"].get(s, {}).get("quantity", 0)*market[s]["mid"]
            quantities, risk_rejections = review(targets, state["positions"], market, config,
                                                 halted=state["halted"], atomic_groups=groups)
            for s, q in quantities.items():
                horizons = [c["horizon_minutes"] for c in contributions if c["symbol"] == s and c["notional_usd"]]
                if s in exploratory:
                    horizons = [exploration["candidate"]["horizon_minutes"]]
                state["pending"][s] = {
                    "quantity": q, "created_ms": asof, "expires_ms": asof+config.max_age_ms,
                    "exploratory": s in exploratory, "reason": exit_reasons.get(s,
                        'exposure-reduction' if s in risk_targets else
                        'signal-reversal' if q == 0 and s in state['positions'] else 'weighted-agent-target'),
                    "horizon_minutes": min(horizons, default=config.horizon_minutes),
                    'strategy_ids': sorted({c['strategy'] for c in contributions if c['symbol'] == s
                                            and c['notional_usd']}),
                    "quote_event_ms": market[s]["event_ms"],
                    "basket_members": list(next((g for g in groups if s in g), ())),
                }
            state["last_ms"] = asof
            record = {
                "schema_version": VERSION, "mode": "offline-paper", "asof_ms": asof,
                "input_hash": input_hash, "config": asdict(config), "snapshot_refs": snapshot_refs,
                "features": public_features(features), "data_rejections": failures,
                "proposals": [p.to_dict() for p in proposals], "request": request,
                "routing": {"model_version": self.model_version, "error": routing_error,
                            "latency_ms": latency_ms, "probabilities": probabilities,
                            "selected": selected, "cumulative_mass": cumulative},
                "contributions": contributions, "exploration": exploration,
                'execution_gate': execution_gate, 'execution_filters': execution_filters,
                'exposure_breach': exposure_breach,
                "target_notionals": targets, "pending_orders": copy.deepcopy(state["pending"]),
                "risk_rejections": risk_rejections, "execution_rejections": execution_rejections,
                "atomic_groups": [list(g) for g in groups],
                "fills": fills, "ledger_events": ledger_events,
                "equity_mid": state["cash"], "equity_oracle_observed": oracle_equity(
                    state, histories, asof, config),
                "valuation_complete": all(s in market for s in state["positions"]),
                "fees": state["fees"], "funding": state["funding"], "turnover": state["turnover"],
                "funding_coverage_complete": state["funding_coverage_complete"],
                "funding_due": list(state["funding_due"]),
                "positions": copy.deepcopy(state["positions"]), "halted": state["halted"],
            }
            self.journal.save(asof, input_hash, record, state)
            return record
