"""Next-observation taker simulator. Research ledger, never an exchange adapter."""
import copy
import math

from .portfolio import review_quantities


def market_at(histories, asof, config):
    market = {}
    for symbol, rows in histories.items():
        if symbol.endswith(":USDJPY"):
            continue
        known = [r for r in rows if r.asof_ms <= asof]
        if not known:
            continue
        row = known[-1]
        if asof-row.event_ms > config.max_age_ms or asof-row.asof_ms > config.max_age_ms:
            continue
        market[symbol] = {"mid": row.mid, "bid": row.bid, "ask": row.ask,
                          "quantity_step": row.quantity_step, "spread_bps": row.spread_bps,
                          "event_ms": row.event_ms, "observed_ms": row.asof_ms}
    return market


def initial_state(equity):
    return {"cash": equity, "initial_equity": equity, "peak_equity": equity,
            "halted": False, "positions": {}, "pending": {}, "exploration": {}, "last_ms": -1,
            "fees": 0.0, "turnover": 0.0, "funding": 0.0, "funding_seen": [],
            "funding_coverage_complete": True, "position_history": {}, "cooldowns": {},
            "funding_due": [], "funding_missing_reference": False, "funding_settled_hours": []}


def mark_and_fund(state, histories, market, asof):
    events = []
    seen = set(state["funding_seen"])
    hours = set(state.setdefault("funding_settled_hours", []))
    previous = state["last_ms"] if state["last_ms"] >= 0 else asof
    for event in range((previous//3600000+1)*3600000, asof+1, 3600000):
        for symbol, changes in state["position_history"].items():
            held = [p for p in changes if p["asof_ms"] < event]
            key = f"{symbol}:{event}"
            if held and held[-1]["quantity"] and key not in hours and key not in state['funding_due']:
                state["funding_due"].append(key)
    for s, p in state["positions"].items():
        if s in market:
            mid = market[s]["mid"]
            state["cash"] += p["quantity"]*(mid-p["last_mid"])
            p["last_mid"] = mid
    for s, rows in histories.items():
        # Process all newly available settlements, not just the last rate at this tick.
        known = [r for r in rows if r.asof_ms <= asof and r.funding_rate is not None]
        for row in known:
            event = row.funding_event_ms
            key = f"{s}:{event}"
            if key in seen:
                continue
            state["funding_seen"].append(key)
            seen.add(key)
            hour_key = f"{s}:{event//3600000*3600000}"
            if hour_key not in hours:
                hours.add(hour_key)
                state["funding_settled_hours"].append(hour_key)
            if hour_key in state["funding_due"]:
                state["funding_due"].remove(hour_key)
            held = [p for p in state["position_history"].get(s, []) if p["asof_ms"] < event]
            quantity = held[-1]["quantity"] if held else 0
            if not quantity:
                continue
            reference = [r for r in rows if r.asof_ms <= event and r.oracle is not None
                         and event-r.context_available_ms <= 90000]
            if not reference:
                state["funding_missing_reference"] = True
                events.append({"kind": "missing-settlement-reference", "symbol": s, "event_ms": event})
                continue
            payment = -quantity*reference[-1].oracle*row.funding_rate
            state["cash"] += payment
            state["funding"] += payment
            events.append({"kind": "funding", "symbol": s, "event_ms": event, "payment": payment})
    state["peak_equity"] = max(state["peak_equity"], state["cash"])
    state["funding_coverage_complete"] = not state["funding_due"] and not state["funding_missing_reference"]
    return events


def _apply_fill(state, symbol, order, quantity, f, asof, config):
    current = state["positions"].get(symbol, {}).get("quantity", 0)
    delta = quantity-current
    if not delta:
        return None
    price = ((f["ask"] if delta > 0 else f["bid"])*
             (1+math.copysign(config.slippage_bps/10000, delta)))
    fee = abs(delta)*price*config.taker_fee_bps/10000
    state["cash"] -= delta*(price-f["mid"])+fee
    state["fees"] += fee
    state["turnover"] += abs(delta)*price
    old = state["positions"].get(symbol)
    if quantity == 0:
        state["positions"].pop(symbol, None)
        state["cooldowns"][symbol] = max(state["cooldowns"].get(symbol, 0),
                                         asof+config.entry_cooldown_minutes*60000)
    else:
        same_side = old and current*quantity > 0
        entry = old["entry_price"] if same_side else price
        if same_side and abs(quantity) > abs(current):
            entry = (abs(current)*entry+abs(delta)*price)/abs(quantity)
        state["positions"][symbol] = {
            "quantity": quantity, "last_mid": f["mid"], "entry_price": entry,
            "opened_ms": old["opened_ms"] if same_side else asof,
            "last_rebalanced_ms": asof,
            "exit_ms": old["exit_ms"] if same_side else
                       asof+order.get("horizon_minutes", config.horizon_minutes)*60000,
            "exploratory": order["exploratory"] or bool(same_side and old["exploratory"]),
            "basket_members": list(order.get("basket_members", ())),
            'entry_strategies': old.get('entry_strategies', []) if same_side else order.get('strategy_ids', []),
        }
    state["position_history"].setdefault(symbol, []).append({"asof_ms": asof, "quantity": quantity})
    return {"symbol": symbol, "quantity_delta": delta, "target_quantity": quantity,
            "price": price, "fee": fee, "exploratory": order["exploratory"],
            "reason": order["reason"], "created_ms": order["created_ms"], "filled_ms": asof,
            "basket_members": list(order.get("basket_members", ()))}


def fill_pending(state, market, asof, config):
    """Preflight each dependent basket, then commit all simulated legs together.

    This is an offline simulator guarantee, not a claim of atomic multi-market exchange orders.
    Absolute quantities are immutable at execution; never round q*mid/mid a second time.
    """
    fills, rejected = [], {}
    old_pending, state["pending"] = state["pending"], {}
    groups = {}
    for s, order in old_pending.items():
        members = tuple(sorted(order.get("basket_members") or (s,)))
        groups[members] = members

    def reducing_group(members):
        return all((state["positions"].get(s, {}).get("quantity", 0)*old_pending.get(s, {}).get("quantity", 0) >= 0
                    and abs(old_pending.get(s, {}).get("quantity", 0)) <=
                    abs(state["positions"].get(s, {}).get("quantity", 0))) for s in members)

    for members in sorted(groups, key=lambda g: (not reducing_group(g), g)):
        atomic = len(members) > 1
        present = {s: old_pending[s] for s in members if s in old_pending}
        reason = None
        if len(present) != len(members) or any(
                tuple(sorted(o.get("basket_members") or (s,))) != members for s, o in present.items()):
            reason = "incomplete-basket-envelope"
        elif any(asof > o["expires_ms"] or s not in market for s, o in present.items()):
            reason = "expired-or-missing-next-quote"
        if reason:
            rejected.update({s: "atomic-basket:"+reason if atomic else reason for s in members})
            continue
        if any(asof <= o["created_ms"] or ("quote_event_ms" in o and
               market[s].get("event_ms", -1) <= o["quote_event_ms"]) for s, o in present.items()):
            state["pending"].update(present)
            continue
        for s, o in present.items():
            f = market[s]
            current = state["positions"].get(s, {}).get("quantity", 0)
            reducing = current*o["quantity"] >= 0 and abs(o["quantity"]) <= abs(current)
            if o["exploratory"] and abs(o["quantity"])*f["mid"] > config.exploration_usd+1e-8:
                reason = "execution-exploration-cap"
            elif not reducing and f["spread_bps"] > config.max_spread_bps:
                reason = "execution-spread-limit"
        if reason:
            rejected.update({s: "atomic-basket:"+reason if atomic else reason for s in members})
            continue
        quantities, reasons = review_quantities({s: o["quantity"] for s, o in present.items()},
                                                state["positions"], market, config, halted=state["halted"],
                                                atomic_groups=(members,) if atomic else ())
        if atomic and set(quantities) != set(members):
            rejected.update({s: "atomic-basket-execution-rejected" for s in members})
            continue
        rejected.update(reasons)
        staged = copy.deepcopy(state)
        batch_fills = []
        for s, quantity in quantities.items():
            fill = _apply_fill(staged, s, present[s], quantity, market[s], asof, config)
            if fill:
                batch_fills.append(fill)
        state.clear()
        state.update(staged)
        fills.extend(batch_fills)
    return fills, rejected


def exits(state, market, asof, config, *, features=None):
    targets, reasons = {}, {}
    for s, p in state["positions"].items():
        if s not in market:
            continue
        gain = (market[s]["mid"]/p["entry_price"]-1)*10000*(1 if p["quantity"] > 0 else -1)
        trend_break = (config.exit_on_trend_break and features and s in features
                       and p.get('entry_strategies') and set(p['entry_strategies']) <= {'S02', 'N01'}
                       and asof-p['opened_ms'] >= config.min_holding_minutes*60000
                       and features[s]['momentum_60_bps']*p['quantity'] <= 0)
        reason = ("supervisor-flatten" if state["halted"] else
                  "holding-expired" if asof >= p["exit_ms"] else
                  "stop-loss" if gain <= -config.stop_loss_bps else
                  "take-profit" if gain >= config.take_profit_bps else
                  'trend-invalidated' if trend_break else None)
        if reason:
            targets[s], reasons[s] = 0.0, reason
            state["cooldowns"][s] = max(p["exit_ms"], asof+config.exploration_cooldown_ms)
    linked = {tuple(sorted(p.get("basket_members", ()))) for p in state["positions"].values()}
    for members in sorted(linked):
        if any(s in targets for s in members):
            cause = next(reasons[s] for s in members if s in reasons)
            for s in members:
                targets[s], reasons[s] = 0.0, "basket-exit:"+cause
                state["cooldowns"][s] = max(state["cooldowns"].get(s, 0),
                                             asof+config.exploration_cooldown_ms)
    return targets, reasons


def oracle_equity(state, histories, asof, config):
    adjustment = 0.0
    for s, p in state["positions"].items():
        known = [r for r in histories.get(s, []) if r.asof_ms <= asof and r.oracle is not None]
        if not known or asof-known[-1].context_available_ms > config.max_age_ms:
            return None
        adjustment += p["quantity"]*(known[-1].oracle-p["last_mid"])
    return state["cash"]+adjustment
