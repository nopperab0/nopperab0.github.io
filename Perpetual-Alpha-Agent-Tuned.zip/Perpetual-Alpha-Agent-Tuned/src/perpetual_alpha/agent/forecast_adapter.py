"""PAR shadow ForecastProducer compatibility; canonical weighted targets stay in last_analysis.

The existing FixedQuantity/BudgetPortfolio policies discard routing weights. This adapter
is for side-by-side forecast evaluation, not for executing the agent's portfolio policy.
"""
import copy

from ..context import SOURCE
from ..contracts import Forecast, ForecastBatch
from ..forecast_validation import validate_context
from ..interfaces import DataRequest
from ..journal import digest
from ..venues import venue
from .features import Observation, build_features, number, public_features
from .portfolio import construct
from .routing import gate, make_request, validate_response
from .strategies import generate


class AgentForecastProducer:
    producer_id = "strategy-agent-shadow"
    producer_version = "1.1"

    def __init__(self, config, router, quantity_steps):
        if config.dex != "par":
            raise ValueError("Existing Forecast protocol is PAR-only; do not relabel PAS")
        self.config, self.router = config, router
        self.quantity_steps = {venue("par").validate_symbol(s): number(step, positive=True)
                               for s, step in quantity_steps.items()}
        if not self.quantity_steps:
            raise ValueError("Explicit nonempty venue quantity steps required")
        self.last_analysis = None

    def requirements(self):
        c = self.config
        return tuple(DataRequest("agent:"+s, SOURCE, "quote", (s,), ("bid", "ask", "mark", "oracle"),
                                 c.history_minutes*60000, c.history_minutes*2+2, c.max_age_ms)
                     for s in sorted(self.quantity_steps))

    def forecast(self, context):
        requests = self.requirements()
        validate_context(context, requests)
        asof, histories = context["asof_ms"], {}
        for request in requests:
            symbol = request.symbols[0]
            minutes = {}
            for row in context["datasets"][request.dataset_id]["records"]:
                minute = ((row["received_ms"]+59999)//60000)*60000
                if minute > asof:
                    continue
                data = row["data"]
                observation = Observation(symbol, minute, row["received_ms"], row["event_ms"],
                                          data["bid"], data["ask"], self.quantity_steps[symbol],
                                          data["oracle"], row["received_ms"])
                if minute not in minutes or observation.available_ms > minutes[minute].available_ms:
                    minutes[minute] = observation
            histories[symbol] = [minutes[t] for t in sorted(minutes)]
        features, failures = build_features(histories, asof, self.config)
        proposals = generate(features, self.config)
        request = make_request(asof, public_features(features), proposals, digest(context))
        probabilities, selected, error = {}, [], None
        if any(p.eligible for p in proposals):
            try:
                response = self.router.route(copy.deepcopy(request))
                probabilities = validate_response(response, request, self.router.model_version)
                selected, _ = gate(probabilities, self.config)
            except Exception as failure:
                error = type(failure).__name__
        targets, contributions = construct(proposals, selected, probabilities, features, self.config)
        self.last_analysis = {"mode": "par-shadow-forecast-only", "request": request,
                              "probabilities": probabilities, "selected": selected, "error": error,
                              "target_notionals": targets, "contributions": contributions,
                              "data_rejections": failures}
        ref = "agent-shadow:"+digest(self.last_analysis)
        items = []
        for symbol in sorted(self.quantity_steps):
            target = targets.get(symbol)
            horizons = [c["horizon_minutes"] for c in contributions if c["symbol"] == symbol and c["notional_usd"]]
            status = "error" if error else "ready" if target is not None else "abstain"
            direction = ("up" if target > 0 else "down" if target < 0 else "neutral") if status == "ready" else None
            items.append(Forecast(symbol, asof, asof+self.config.max_age_ms,
                                  min(horizons, default=self.config.horizon_minutes)*60000, status, direction,
                                  ("agent:"+symbol,) if status == "ready" else (),
                                  "SHADOW ONLY; weighted targets require agent portfolio, not fixed sizing",
                                  distribution_ref=ref if status == "ready" else None,
                                  model_version=self.router.model_version, prompt_version="regime-choice/1.1"))
        return ForecastBatch(context["context_id"]+":agent-shadow", context["context_id"],
                             self.producer_id, self.producer_version, asof, tuple(items))
