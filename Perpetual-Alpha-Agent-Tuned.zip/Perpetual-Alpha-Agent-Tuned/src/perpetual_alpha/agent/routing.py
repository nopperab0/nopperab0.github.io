"""One full Choice distribution per portfolio snapshot; user supplies Jev transport."""
import copy
import math
from typing import Protocol

from ..journal import digest
from .features import number
from .strategies import CATALOG, OPTIONS


class Router(Protocol):
    model_version: str

    def route(self, request: dict) -> dict: ...


def make_request(asof, features, proposals, snapshot_id, sentiment=None):
    eligible = {p.strategy for p in proposals if p.eligible}
    request = {
        "schema_version": "agent-choice-request/1", "asof_ms": asof, "snapshot_id": snapshot_id,
        "prompt_version": "regime-choice/1.1",
        "question": "Which eligible strategy setup best matches the supplied market regime after costs? "
                    "Choose NO_TRADE when evidence is insufficient. Edge fields are uncalibrated signal proxies, "
                    "not expected profits. Historical funding is not guaranteed future carry.",
        "options": {**{k: v for k, v in CATALOG.items() if k in eligible},
                    "NO_TRADE": "No new exposure; existing exits remain active"},
        "features": features, "proposals": [p.to_dict() for p in proposals if p.eligible],
        "sentiment": sentiment,
    }
    return {**request, "request_id": digest(request)}


def validate_response(response, request, model_version):
    expected = {"schema_version", "request_id", "model_version", "probabilities"}
    if not isinstance(response, dict) or set(response) != expected:
        raise ValueError("Full routing response envelope required")
    if (response["schema_version"] != "agent-routing/1" or response["request_id"] != request["request_id"]
            or response["model_version"] != model_version or not model_version):
        raise ValueError("Routing identity/version mismatch")
    raw = response["probabilities"]
    options = request["options"]
    if not isinstance(raw, dict) or set(raw) != set(options):
        raise ValueError("Probability keys must exactly match this request's eligible options")
    probabilities = {k: number(raw[k]) for k in options}
    if any(not 0 <= v <= 1 for v in probabilities.values()) or abs(math.fsum(probabilities.values())-1) > 1e-6:
        raise ValueError("Invalid Choice probability mass")
    return probabilities


class JevRouter:
    """Transport gets a copy; return an internal envelope. No guessed endpoint or SDK fields."""
    def __init__(self, transport, model_version):
        if not callable(transport) or not isinstance(model_version, str) or not model_version.strip():
            raise ValueError("Callable transport and pinned model required")
        self.transport, self.model_version = transport, model_version

    def route(self, request):
        return self.transport(copy.deepcopy(request))


class RuleRouter:
    """Explicit non-Jev comparison. No automatic fallback on Jev failure."""
    model_version = "python-regime-baseline/1"

    def route(self, request):
        scores = {key: 0.0 for key in request["options"]}
        scores["NO_TRADE"] = 1.0
        for p in request["proposals"]:
            if p["eligible"]:
                scores[p["strategy"]] = max(scores[p["strategy"]],
                                            min(10, p["net_edge_bps"]/max(p["risk_bps"], 1)))
        total = math.fsum(scores.values())
        return {"schema_version": "agent-routing/1", "request_id": request["request_id"],
                "model_version": self.model_version,
                "probabilities": {k: v/total for k, v in scores.items()}}


def gate(probabilities, config):
    ranked = sorted(probabilities, key=lambda k: (-probabilities[k], OPTIONS.index(k)))
    selected, cumulative = [], 0.0
    for key in ranked:
        if probabilities[key] == 0:
            continue
        selected.append(key)
        cumulative = math.fsum(probabilities[k] for k in selected)
        if config.gate == "top_p" and cumulative+1e-12 >= config.top_p:
            break
        if config.gate == "top_k" and len(selected) >= config.top_k:
            break
    return selected, cumulative
