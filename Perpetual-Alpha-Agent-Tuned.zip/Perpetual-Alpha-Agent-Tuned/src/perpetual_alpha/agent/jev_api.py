"""TypeSafe direct HTTP transport. Fill .env.jev, not this source file.

Official contract: https://docs.typesafe.ai/primitives/choice
POST https://api.typesafe.ai/v1/systemone
No retries, redirects, exchange credentials, or orders.
"""
import http.client
import json
import math
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from .data import no_duplicates
from .routing import validate_response

ENV_FILE = Path(__file__).resolve().parents[3]/".env.jev"
MAX_RESPONSE = 65536


class JevConfigurationError(ValueError):
    pass


class JevHTTPError(RuntimeError):
    pass


@dataclass(frozen=True)
class JevConfig:
    api_key: str = field(repr=False)
    model: str = "jev-1.14.0"
    timeout_seconds: float = 1.8

    def __post_init__(self):
        if (not isinstance(self.api_key, str) or not self.api_key or
                any(ord(c) < 33 or ord(c) > 126 for c in self.api_key)):
            raise JevConfigurationError("Fill TYPESAFE_API_KEY in .env.jev")
        if not isinstance(self.model, str) or not re.fullmatch(r"jev-\d+\.\d+\.\d+", self.model):
            raise JevConfigurationError("Use a pinned JEV_MODEL such as jev-1.14.0")
        if (type(self.timeout_seconds) not in {int, float} or not math.isfinite(self.timeout_seconds)
                or not 0 < self.timeout_seconds <= 30):
            raise JevConfigurationError("Invalid JEV_TIMEOUT_SECONDS")


def load_config(path=ENV_FILE):
    values = {}
    path = Path(path)
    if path.exists():
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            key, separator, value = line.partition("=")
            key, value = key.strip(), value.strip()
            if (not separator or key not in {"TYPESAFE_API_KEY", "JEV_MODEL", "JEV_TIMEOUT_SECONDS"}
                    or key in values):
                raise JevConfigurationError("Invalid or duplicate Jev configuration field")
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                value = value[1:-1]
            values[key] = value
    for key in ("TYPESAFE_API_KEY", "JEV_MODEL", "JEV_TIMEOUT_SECONDS"):
        if key in os.environ:
            values[key] = os.environ[key]
    try:
        timeout = float(values.get("JEV_TIMEOUT_SECONDS", "1.8"))
    except ValueError:
        raise JevConfigurationError("Invalid JEV_TIMEOUT_SECONDS") from None
    return JevConfig(values.get("TYPESAFE_API_KEY", ""), values.get("JEV_MODEL", "jev-1.14.0"), timeout)


def request_choice(request, *, config=None):
    config = config or load_config()
    body = {
        "model": config.model,
        "state": {k: request[k] for k in ("asof_ms", "snapshot_id", "features", "proposals", "sentiment")},
        "questions": {"strategy": {"type": "choice", "instructions": request["question"],
                                    "criteria": request["options"]}},
    }
    connection = http.client.HTTPSConnection("api.typesafe.ai", timeout=config.timeout_seconds)
    started = time.monotonic()
    try:
        connection.request("POST", "/v1/systemone", json.dumps(body, allow_nan=False).encode("utf-8"),
                           {"Authorization": "Bearer "+config.api_key, "Content-Type": "application/json"})
        response = connection.getresponse()
        if response.status != 200:
            raise JevHTTPError("TypeSafe HTTP status "+str(response.status))
        chunks, size = [], 0
        while True:
            remaining = config.timeout_seconds-(time.monotonic()-started)
            if remaining <= 0:
                raise TimeoutError("Jev response exceeded the receive deadline")
            if connection.sock is not None:
                connection.sock.settimeout(remaining)
            chunk = response.read1(min(4096, MAX_RESPONSE+1-size))
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_RESPONSE:
                raise ValueError("Jev response too large")
            chunks.append(chunk)
        if time.monotonic()-started > config.timeout_seconds:
            raise TimeoutError("Jev response exceeded the receive deadline")
        payload = json.loads(b"".join(chunks), object_pairs_hook=no_duplicates,
                             parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Invalid JSON number")))
        answer = payload["answers"]["strategy"]
        if answer["type"] != "choice" or answer["choice"] not in request["options"]:
            raise ValueError("Invalid Jev Choice answer")
        result = {"schema_version": "agent-routing/1", "request_id": request["request_id"],
                  "model_version": payload["model"], "probabilities": answer["probabilities"]}
        validate_response(result, request, config.model)
        return result
    finally:
        connection.close()
