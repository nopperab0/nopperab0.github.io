import contextlib
import copy
import hashlib
import io
import json
import tempfile
import unittest
from contextlib import closing
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from perpetual_alpha.agent.cli import main
from perpetual_alpha.agent.config import AgentConfig
from perpetual_alpha.agent.data import read_panel_csv, read_pas_db, snapshot_json, synthetic_observations
from perpetual_alpha.agent.harness import AgentHarness
from perpetual_alpha.agent.journal import AgentJournal
from perpetual_alpha.agent.paper import initial_state
from perpetual_alpha.agent.routing import JevRouter, RuleRouter
from perpetual_alpha.examples.pas_research_fixture import START, create
from perpetual_alpha.pas_research import checked_derived, ingest, panel, write_csv
from perpetual_alpha.venues import venue


class AgentIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def invoke(self, args):
        with contextlib.redirect_stdout(io.StringIO()):
            main(args)

    def test_repository_pas_pipeline_csv_and_db_are_identical_and_read_only(self):
        raw, derived = self.root/"raw.sqlite3", self.root/"derived.sqlite3"
        create(raw)
        ingest(raw, derived)
        output = self.root/"panel-export"
        output.mkdir()
        with closing(checked_derived(derived)) as db:
            write_csv(output/"panel.csv", list(panel(db, START, START+12*60000)))
        steps = {s: .00001 for s in venue("pas").symbols}
        before = hashlib.sha256(derived.read_bytes()).hexdigest()
        a = read_pas_db(derived, START, START+12*60000, steps)
        b = read_panel_csv(output/"panel.csv", steps, "pas")
        self.assertTrue(a)
        self.assertEqual(a, b)
        self.assertEqual(hashlib.sha256(derived.read_bytes()).hexdigest(), before)
        with self.assertRaises(ValueError):
            read_panel_csv(output/"panel.csv", steps, "par")

    def test_cli_request_captured_decide_and_next_snapshot_resume(self):
        snapshot = self.root/"snapshot.json"
        payload = snapshot_json(synthetic_observations(250))
        snapshot.write_text(json.dumps(payload), encoding="utf-8")
        request_file, response_file = self.root/"request.json", self.root/"response.json"
        self.invoke(["request", "--snapshot", str(snapshot), "--out", str(request_file)])
        request = json.loads(request_file.read_text(encoding="utf-8"))
        envelope = {"schema_version": "agent-routing/1", "request_id": request["request_id"],
                    "model_version": "captured-test/1", "probabilities": {
                        k: .4 if k == "S02" else .6 if k == "NO_TRADE" else 0 for k in request["options"]}}
        response_file.write_text(json.dumps(envelope), encoding="utf-8")
        journal, output = self.root/"decisions.sqlite3", self.root/"decision.json"
        args = ["decide", "--snapshot", str(snapshot), "--out", str(output), "--journal", str(journal),
                "--router", "captured", "--responses", str(response_file), "--model-version", "captured-test/1"]
        self.invoke(args)
        first = json.loads(output.read_text(encoding="utf-8"))
        self.assertEqual(first["routing"]["selected"], ["NO_TRADE", "S02"])
        self.invoke(args)
        self.assertEqual(first, json.loads(output.read_text(encoding="utf-8")))
        snapshot.write_text(json.dumps(snapshot_json(synthetic_observations(251))), encoding="utf-8")
        self.invoke(["request", "--snapshot", str(snapshot), "--out", str(request_file)])
        request = json.loads(request_file.read_text(encoding="utf-8"))
        envelope["request_id"] = request["request_id"]
        envelope["probabilities"] = {k: .4 if k == "S02" else .6 if k == "NO_TRADE" else 0
                                     for k in request["options"]}
        response_file.write_text(json.dumps(envelope), encoding="utf-8")
        self.invoke(args)
        second = json.loads(output.read_text(encoding="utf-8"))
        self.assertGreater(second["asof_ms"], first["asof_ms"])
        self.assertTrue(second["fills"])

    def test_request_output_cannot_alias_input(self):
        snapshot = self.root/"snapshot.json"
        snapshot.write_text(json.dumps(snapshot_json(synthetic_observations(2))), encoding="utf-8")
        before = snapshot.read_bytes()
        with self.assertRaises(ValueError):
            self.invoke(["request", "--snapshot", str(snapshot), "--out", str(snapshot)])
        self.assertEqual(snapshot.read_bytes(), before)

    def test_late_routing_is_rejected_without_fallback(self):
        payload = snapshot_json(synthetic_observations(250))
        from perpetual_alpha.agent.features import Observation
        histories = {s: [Observation(**r) for r in rows] for s, rows in payload["histories"].items()}
        journal = AgentJournal(self.root/"late.sqlite3", {"test": "late"})
        self.addCleanup(journal.close)
        with patch("perpetual_alpha.agent.harness.time.monotonic", side_effect=[0, 3]):
            result = AgentHarness(AgentConfig(), RuleRouter(), journal).step(histories, payload["asof_ms"])
        self.assertEqual(result["routing"]["error"], "inference-time-budget")
        self.assertFalse(result["pending_orders"])

    def test_invalid_sentiment_still_manages_expiring_position(self):
        payload = snapshot_json(synthetic_observations(250))
        from perpetual_alpha.agent.features import Observation
        histories = {s: [Observation(**r) for r in rows] for s, rows in payload["histories"].items()}
        journal = AgentJournal(self.root/"sentiment.sqlite3", {"test": "sentiment"})
        self.addCleanup(journal.close)
        state = initial_state(100000)
        mid = histories["pas:BTC"][-1].mid
        state["positions"]["pas:BTC"] = {"quantity": .001, "last_mid": mid, "entry_price": mid,
                                         "opened_ms": 0, "exit_ms": 1, "exploratory": False}
        with journal.transaction():
            journal.db.execute("INSERT INTO state VALUES(1,?)", (json.dumps(state),))
        result = AgentHarness(AgentConfig(), RuleRouter(), journal).step(histories, payload["asof_ms"],
                                                                      sentiment={"bad": "data"})
        self.assertEqual(result["routing"]["error"], "invalid-or-stale-sentiment")
        self.assertEqual(result["pending_orders"]["pas:BTC"]["quantity"], 0)

    def test_future_append_is_idempotent_and_no_trade_retains_unexpired_position(self):
        from perpetual_alpha.agent.features import Observation
        payload = snapshot_json(synthetic_observations(250))
        histories = {s: [Observation(**r) for r in rows] for s, rows in payload["histories"].items()}
        journal = AgentJournal(self.root/"hold.sqlite3", {"test": "hold"})
        self.addCleanup(journal.close)
        state = initial_state(100000)
        mid, now = histories["pas:BTC"][-1].mid, payload["asof_ms"]
        state["positions"]["pas:BTC"] = {"quantity": .001, "last_mid": mid, "entry_price": mid,
                                         "opened_ms": now-1000, "exit_ms": now+3600000, "exploratory": False}
        with journal.transaction():
            journal.db.execute("INSERT INTO state VALUES(1,?)", (json.dumps(state),))
        router = JevRouter(lambda r: {"schema_version": "agent-routing/1", "request_id": r["request_id"],
                                     "model_version": "no-trade/1", "probabilities": {
                                         k: float(k == "NO_TRADE") for k in r["options"]}}, "no-trade/1")
        harness = AgentHarness(AgentConfig(), router, journal)
        result = harness.step(histories, now)
        self.assertEqual(result["positions"]["pas:BTC"]["quantity"], .001)
        self.assertFalse(result["pending_orders"])
        future = copy.deepcopy(histories)
        future["pas:BTC"].append(replace(future["pas:BTC"][-1], asof_ms=now+60000,
                                          available_ms=now+60000, event_ms=now+60000))
        self.assertEqual(result, harness.step(future, now))


if __name__ == "__main__":
    unittest.main()
