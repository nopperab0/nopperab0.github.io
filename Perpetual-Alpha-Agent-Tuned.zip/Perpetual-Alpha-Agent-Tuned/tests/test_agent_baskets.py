"""Regression cases for basket integrity before approval, at fill, and at exit."""
import copy
import unittest
from dataclasses import replace

from perpetual_alpha.agent.config import AgentConfig
from perpetual_alpha.agent.paper import exits, fill_pending, initial_state
from perpetual_alpha.agent.portfolio import basket_groups, construct, review
from perpetual_alpha.agent.routing import RuleRouter, make_request, validate_response
from perpetual_alpha.agent.strategies import Proposal

BTC, ETH = "pas:BTC", "pas:ETH"
PAIR = (BTC, ETH)


def market():
    return {s: {"mid": 100.0, "bid": 99.99, "ask": 100.01, "quantity_step": .01,
                "spread_bps": 2.0, "event_ms": 60000, "observed_ms": 60000} for s in PAIR}


def orders(eth_quantity=-1):
    return {s: {"quantity": q, "created_ms": 0, "expires_ms": 90000, "quote_event_ms": 0,
                "reason": "test", "exploratory": False, "horizon_minutes": 15,
                "basket_members": list(PAIR)} for s, q in ((BTC, 1), (ETH, eth_quantity))}


def position(quantity, *, exit_ms=900000):
    return {"quantity": quantity, "entry_price": 100, "last_mid": 100, "opened_ms": 0,
            "exit_ms": exit_ms, "exploratory": False, "basket_members": list(PAIR)}


class BasketTests(unittest.TestCase):
    def setUp(self):
        self.config = AgentConfig(epsilon=0)
        self.state = initial_state(100000)
        self.market = market()

    def test_review_rejects_both_when_second_leg_is_nine_dollars(self):
        targets, reasons = review({BTC: 100, ETH: -9}, {}, self.market, self.config, atomic_groups=(PAIR,))
        self.assertEqual(targets, {})
        self.assertEqual(set(reasons), set(PAIR))

    def test_rounding_one_leg_to_dust_vetoes_pair(self):
        self.market[ETH]["quantity_step"] = 1
        result, _ = review({BTC: 100, ETH: -10.1}, {}, self.market, self.config, atomic_groups=(PAIR,))
        self.assertFalse(result)

    def test_missing_market_vetoes_pair_at_plan_and_fill(self):
        self.market.pop(ETH)
        result, _ = review({BTC: 100, ETH: -100}, {}, self.market, self.config, atomic_groups=(PAIR,))
        self.assertFalse(result)
        self.state["pending"] = orders()
        fills, rejected = fill_pending(self.state, self.market, 60000, self.config)
        self.assertFalse(fills)
        self.assertEqual(set(rejected), set(PAIR))
        self.assertEqual(self.state["cash"], 100000)
        self.assertEqual(self.state["positions"], {})

    def test_execution_spread_failure_never_charges_or_fills_other_leg(self):
        self.state["pending"] = orders()
        self.market[ETH]["spread_bps"] = 100
        fills, rejected = fill_pending(self.state, self.market, 60000, self.config)
        self.assertFalse(fills)
        self.assertEqual(set(rejected), set(PAIR))
        self.assertEqual(self.state["turnover"], 0)
        self.assertEqual(self.state["fees"], 0)

    def test_price_move_below_order_minimum_is_rechecked_as_a_basket(self):
        self.state["pending"] = orders(-.1)
        self.market[ETH].update(mid=90, bid=89.99, ask=90.01)
        fills, rejected = fill_pending(self.state, self.market, 60000, self.config)
        self.assertFalse(fills)
        self.assertEqual(set(rejected), set(PAIR))
        self.assertFalse(self.state["positions"])

    def test_incomplete_pending_envelope_cannot_execute(self):
        self.state["pending"] = {BTC: orders()[BTC]}
        fills, rejected = fill_pending(self.state, self.market, 60000, self.config)
        self.assertFalse(fills)
        self.assertIn("incomplete-basket", rejected[BTC])

    def test_pair_waits_until_both_books_advance(self):
        self.state["pending"] = orders()
        self.market[ETH]["event_ms"] = 0
        self.assertFalse(fill_pending(self.state, self.market, 30000, self.config)[0])
        self.assertEqual(set(self.state["pending"]), set(PAIR))
        self.market[ETH]["event_ms"] = 60000
        fills, rejected = fill_pending(self.state, self.market, 60000, self.config)
        self.assertEqual(len(fills), 2)
        self.assertFalse(rejected)
        self.assertEqual(set(self.state["positions"]), set(PAIR))
        self.assertEqual({p["exit_ms"] for p in self.state["positions"].values()}, {960000})

    def test_unchanged_leg_can_fulfil_basket_without_fake_fill(self):
        self.state["positions"][BTC] = position(1)
        self.state["pending"] = orders()
        fills, rejected = fill_pending(self.state, self.market, 60000, self.config)
        self.assertFalse(rejected)
        self.assertEqual([f["symbol"] for f in fills], [ETH])
        self.assertEqual(self.state["positions"][BTC]["quantity"], 1)

    def test_one_leg_stop_or_expiry_flattens_both_and_missing_quote_vetoes_exit(self):
        self.state["positions"] = {BTC: position(1, exit_ms=1), ETH: position(-1, exit_ms=999999)}
        targets, reasons = exits(self.state, self.market, 60000, self.config)
        self.assertEqual(targets, {BTC: 0, ETH: 0})
        self.assertTrue(all(r.startswith("basket-exit:") for r in reasons.values()))
        missing = {BTC: self.market[BTC]}
        quantities, _ = review(targets, self.state["positions"], missing, self.config, atomic_groups=(PAIR,))
        self.assertFalse(quantities)
        quantities, _ = review(targets, self.state["positions"], self.market, self.config, atomic_groups=(PAIR,))
        self.assertEqual(quantities, {BTC: 0, ETH: 0})

    def test_no_second_quantity_rounding_at_execution(self):
        self.market[BTC].update(mid=999999, bid=999998, ask=1000000, quantity_step=.00001)
        order = {**orders()[BTC], "quantity": .00003, "basket_members": []}
        self.state["pending"] = {BTC: order}
        fills, rejected = fill_pending(self.state, self.market, 60000, self.config)
        self.assertFalse(rejected)
        self.assertEqual(fills[0]["target_quantity"], .00003)

    def test_netting_cannot_turn_rotation_into_a_one_sided_setup(self):
        proposals = [Proposal("N03", BTC, 1, 100, 20, 50, None, 0, True, "test"),
                     Proposal("N03", ETH, -1, 100, 20, 50, None, 0, True, "test"),
                     Proposal("S02", ETH, 1, 100, 20, 50, None, 0, True, "test")]
        targets, contributions = construct(proposals, ["N03", "S02"], {"N03": .2, "S02": .8}, {}, self.config)
        self.assertNotIn(BTC, targets)
        self.assertEqual(targets[ETH], 800)
        self.assertFalse(basket_groups(contributions, {}, targets))
        self.assertTrue(all(c.get("suppressed_reason") for c in contributions if c["strategy"] == "N03"))

    def test_basket_veto_rechecks_retained_exposure_before_approving_other_trades(self):
        config = replace(self.config, max_asset_usd=1000)
        positions = {BTC: position(5), ETH: position(-.09)}
        quotes = {**self.market, "pas:HYPE": self.market[BTC]}
        # The 9-dollar ETH exit fails, so neither pair leg closes. HYPE cannot use that presumed capacity.
        targets, reasons = review({BTC: 0, ETH: 0, "pas:HYPE": 600}, positions, quotes, config,
                                  atomic_groups=(PAIR,))
        self.assertFalse(targets)
        self.assertIn("pas:HYPE", reasons)


class EligibleOptionsTests(unittest.TestCase):
    def test_only_currently_eligible_options_are_in_the_model_request(self):
        proposals = [Proposal("S02", BTC, 1, 100, 20, 50, None, 0, True, "test"),
                     Proposal("S14", BTC, -1, 0, 20, 50, None, 0, False, "no-signal")]
        request = make_request(1, {}, proposals, "snapshot")
        self.assertEqual(set(request["options"]), {"S02", "NO_TRADE"})
        self.assertEqual(len(request["proposals"]), 1)
        baseline = RuleRouter().route(request)
        validate_response(baseline, request, RuleRouter.model_version)
        extra = copy.deepcopy(baseline)
        extra["probabilities"]["S14"] = 0
        with self.assertRaises(ValueError):
            validate_response(extra, request, RuleRouter.model_version)

    def test_empty_eligible_set_has_only_no_trade(self):
        request = make_request(1, {}, [], "snapshot")
        self.assertEqual(list(request["options"]), ["NO_TRADE"])
        self.assertEqual(RuleRouter().route(request)["probabilities"], {"NO_TRADE": 1})

    def test_per_strategy_horizons_are_validated_without_claiming_calibration(self):
        config = replace(AgentConfig(), strategy_horizon_minutes={"N02": 15, "S14": 240})
        self.assertEqual(config.horizon_for("N02"), 15)
        self.assertEqual(config.horizon_for("S14"), 240)
        self.assertEqual(config.horizon_for("S02"), 60)
        for value in ({"WRONG": 15}, {"N02": 0}, {"N02": True}):
            with self.assertRaises(ValueError):
                replace(config, strategy_horizon_minutes=value)
        payload = Proposal("S14", BTC, -1, 100, 20, 50, None, 0, True, "test").to_dict()
        self.assertFalse(payload["edge_calibrated"])
        self.assertTrue(payload["funding_is_historical"])


if __name__ == "__main__":
    unittest.main()
