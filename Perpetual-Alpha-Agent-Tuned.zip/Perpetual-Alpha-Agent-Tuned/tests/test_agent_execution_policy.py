import unittest
from dataclasses import replace

from perpetual_alpha.agent.config import AgentConfig
from perpetual_alpha.agent.execution_policy import exposure_reductions, filter_targets
from perpetual_alpha.agent.features import Observation
from perpetual_alpha.agent.paper import exits, initial_state, mark_and_fund
from perpetual_alpha.agent.portfolio import construct
from perpetual_alpha.agent.strategies import Proposal


class ExecutionPolicyTests(unittest.TestCase):
    def test_relative_pair_uses_shared_risk_scale_for_equal_dollar_legs(self):
        proposals = [Proposal('N03', s, direction, 100, 24, risk, None, 0, True, 'test')
                     for s,direction,risk in [('pas:BTC', 1, 20), ('pas:ETH', -1, 100)]]
        targets, _ = construct(proposals, ['N03'], {'N03': 1}, {}, AgentConfig())
        self.assertEqual(targets, {'pas:BTC':250, 'pas:ETH':-250})

    def test_trend_invalidation_does_not_close_a_mean_reversion_position(self):
        state = initial_state(100000)
        p = {'quantity':1, 'entry_price':100, 'opened_ms':0, 'exit_ms':240*60000,
             'entry_strategies':['S02']}
        state['positions']['pas:BTC'] = p
        config = replace(AgentConfig(), exit_on_trend_break=True, min_holding_minutes=60)
        targets, reasons = exits(state, {'pas:BTC':{'mid':100}}, 61*60000, config,
                                 features={'pas:BTC':{'momentum_60_bps':-10}})
        self.assertEqual(targets, {'pas:BTC':0})
        self.assertEqual(reasons['pas:BTC'], 'trend-invalidated')
        p['entry_strategies'] = ['S03']
        self.assertFalse(exits(state, {'pas:BTC':{'mid':100}}, 61*60000, config,
                               features={'pas:BTC':{'momentum_60_bps':-10}})[0])

    def test_mark_drift_schedules_reduction(self):
        config = AgentConfig()
        market = {'pas:HYPE': {'mid': 100}}
        positions = {'pas:HYPE': {'quantity': 5.0013}}
        self.assertEqual(exposure_reductions(positions, market, config), {'pas:HYPE': 475.0})

    def test_probabilistic_noise_does_not_resize_or_reverse_early(self):
        config = replace(AgentConfig(), min_holding_minutes=30, rebalance_fraction=.5,
                         close_before_reverse=True)
        market = {'pas:BTC': {'mid': 100}}
        positions = {'pas:BTC': {'quantity': 2, 'opened_ms': 0, 'last_rebalanced_ms': 0}}
        targets, _ = filter_targets({'pas:BTC': -200}, positions, market, 10*60000, config)
        self.assertFalse(targets)
        targets, _ = filter_targets({'pas:BTC': 210}, positions, market, 31*60000, config)
        self.assertFalse(targets)
        targets, _ = filter_targets({'pas:BTC': -200}, positions, market, 31*60000, config)
        self.assertEqual(targets, {'pas:BTC': 0})

    def test_hourly_receipt_millisecond_offset_clears_coverage_without_changing_payment(self):
        state = initial_state(100000)
        state['last_ms'] = 3599999
        state['position_history']['pas:BTC'] = [{'asof_ms': 0, 'quantity': 2}]
        mark_and_fund(state, {}, {}, 3600000)
        self.assertFalse(state['funding_coverage_complete'])
        prior = Observation('pas:BTC', 3600000, 3599900, 3599800, 99, 101, .1, 100, 3599900)
        receipt = Observation('pas:BTC', 3660000, 3660000, 3660000, 99, 101, .1,
                              100, 3660000, .001, 3600014, 3660000)
        mark_and_fund(state, {'pas:BTC': [prior, receipt]}, {}, 3660000)
        self.assertTrue(state['funding_coverage_complete'])
        self.assertEqual(state['funding_due'], [])
        self.assertAlmostEqual(state['funding'], -.2)
        mark_and_fund(state, {'pas:BTC': [prior, receipt]}, {}, 3660000)
        self.assertAlmostEqual(state['funding'], -.2)
