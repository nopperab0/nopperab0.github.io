"""Causal, probability, risk, recovery and execution invariants of the offline agent."""
import copy
import json
import math
import tempfile
import unittest
from dataclasses import asdict, replace
from pathlib import Path

from perpetual_alpha.agent.config import AgentConfig, load_config
from perpetual_alpha.agent.data import grouped, no_duplicates, synthetic_observations
from perpetual_alpha.agent.exploration import choose
from perpetual_alpha.agent.features import Observation, build_features
from perpetual_alpha.agent.forecast_adapter import AgentForecastProducer
from perpetual_alpha.agent.harness import AgentHarness, checked_sentiment
from perpetual_alpha.agent.journal import AgentJournal
from perpetual_alpha.agent.paper import fill_pending, initial_state, mark_and_fund
from perpetual_alpha.agent.portfolio import construct, review
from perpetual_alpha.agent.routing import JevRouter, RuleRouter, gate, make_request, validate_response
from perpetual_alpha.agent.strategies import OPTIONS, Proposal, generate, scenario
from perpetual_alpha.forecasting import checked_forecast
from perpetual_alpha.producers import ProducerRegistry


def distribution(**kwargs):
    return {key: kwargs.get(key, 0.0) for key in OPTIONS}


def histories(minutes=250):
    result = {}
    for row in synthetic_observations(minutes):
        result.setdefault(row.symbol, []).append(row)
    return result


def response(request, probabilities, model="test-choice/1"):
    return {"schema_version": "agent-routing/1", "request_id": request["request_id"],
            "model_version": model, "probabilities": {k: probabilities[k] for k in request["options"]}}


class AgentProbabilityTests(unittest.TestCase):
    def test_last_conversation_example_preserves_original_mass(self):
        probabilities = distribution(S02=.32, S03=.21, N01=.16, S04=.11, NO_TRADE=.10,
                                     S14=.05, N02=.025, N03=.015, N04=.01)
        selected, mass = gate(probabilities, AgentConfig())
        self.assertEqual(selected, ["S02", "S03", "N01", "S04", "NO_TRADE"])
        self.assertAlmostEqual(mass, .9)
        f = {"pas:BTC": {"mid": 100}}
        proposals = [Proposal(k, "pas:BTC", 1, 100, 20, 50, None, 0, True, "test")
                     for k in OPTIONS if k != "NO_TRADE"]
        targets, contributions = construct(proposals, selected, probabilities, f, AgentConfig())
        self.assertAlmostEqual(targets["pas:BTC"], 800)
        self.assertAlmostEqual(sum(c["probability"] for c in contributions), .8)

    def test_threshold_equality_one_and_stable_ties(self):
        p = distribution(S02=.5, NO_TRADE=.5)
        self.assertEqual(gate(p, AgentConfig(top_p=.5))[0], ["S02"])
        self.assertEqual(gate(p, AgentConfig(top_p=1))[0], ["S02", "NO_TRADE"])
        self.assertEqual(gate(p, AgentConfig(gate="top_k", top_k=1))[0], ["S02"])
        self.assertEqual(gate(p, AgentConfig(gate="all"))[0], ["S02", "NO_TRADE"])

    def test_invalid_probabilities_and_bindings(self):
        request = {"request_id": "a", "options": dict.fromkeys(OPTIONS)}
        valid = response(request, distribution(S02=.8, NO_TRADE=.2))
        self.assertAlmostEqual(validate_response(valid, request, "test-choice/1")["S02"], .8)
        bad = []
        for value in (-1, float("nan"), float("inf"), True, 1.2):
            changed = copy.deepcopy(valid)
            changed["probabilities"]["S02"] = value
            bad.append(changed)
        for key, value in (("request_id", "wrong"), ("model_version", "wrong")):
            bad.append({**valid, key: value})
        missing = copy.deepcopy(valid)
        del missing["probabilities"]["N04"]
        bad.append(missing)
        bad.append({**valid, "probabilities": distribution(S02=.7, NO_TRADE=.2)})
        for payload in bad:
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                validate_response(payload, request, "test-choice/1")
        with self.assertRaises(ValueError):
            json.loads('{"a":1,"a":2}', object_pairs_hook=no_duplicates)

    def test_asset_netting_and_one_budget_across_markets(self):
        proposals = [Proposal("S02", s, 1, 100, 20, 50, None, 0, True, "test")
                     for s in ("pas:BTC", "pas:ETH")]
        proposals.append(Proposal("S03", "pas:BTC", -1, 100, 20, 50, None, 0, True, "test"))
        targets, _ = construct(proposals, ["S02", "S03"], distribution(S02=.4, S03=.2, NO_TRADE=.4),
                               {}, AgentConfig())
        self.assertAlmostEqual(targets["pas:BTC"], 0)
        self.assertAlmostEqual(targets["pas:ETH"], 200)


class AgentFeatureTests(unittest.TestCase):
    def test_future_rows_do_not_change_features_or_request(self):
        h = histories(300)
        asof = h["pas:BTC"][249].asof_ms
        short = {s: rows[:250] for s, rows in h.items()}
        a, _ = build_features(h, asof, AgentConfig())
        b, _ = build_features(short, asof, AgentConfig())
        self.assertEqual(a, b)
        self.assertEqual(generate(a, AgentConfig()), generate(b, AgentConfig()))

    def test_missing_repeated_and_future_data(self):
        h = histories()
        s = "pas:BTC"
        asof = h[s][-1].asof_ms
        h[s].pop(-20)
        f, failures = build_features(h, asof, AgentConfig())
        self.assertNotIn(s, f)
        self.assertIn(s, failures)
        h = histories()
        h[s][-1] = replace(h[s][-1], event_ms=h[s][-2].event_ms)
        self.assertNotIn(s, build_features(h, asof, AgentConfig())[0])
        with self.assertRaises(ValueError):
            replace(h[s][-1], available_ms=asof+1)
        h["par:BTC"] = h.pop(s)
        with self.assertRaises(ValueError):
            build_features(h, asof, AgentConfig())

    def test_oracle_and_funding_ttl_and_sentiment(self):
        h = histories()
        asof = h["pas:BTC"][-1].asof_ms
        h["pas:BTC"][-1] = replace(h["pas:BTC"][-1], context_available_ms=asof-100000,
                                   funding_event_ms=asof-8000000, funding_available_ms=asof-8000000)
        f = build_features(h, asof, AgentConfig())[0]["pas:BTC"]
        self.assertIsNone(f["basis_bps"])
        self.assertIsNone(f["funding_rate"])
        factor = {"available_ms": asof, "expires_ms": asof+1, "score": .2, "source_id": "fixture"}
        self.assertEqual(checked_sentiment(factor, asof), factor)
        with self.assertRaises(ValueError):
            checked_sentiment(factor, asof+1)

    def test_minimum_scenario_evidence(self):
        self.assertIsNone(scenario([1]*1000, 1, AgentConfig(), 20)[0])
        upper, count = scenario([1+0.0001*i for i in range(1441)], 1, AgentConfig(), 20)
        self.assertEqual(count, 24)
        self.assertGreater(upper, 0)

    def test_all_strategies_are_concrete_and_cost_filtered(self):
        h = histories()
        f, _ = build_features(h, h["pas:BTC"][-1].asof_ms, AgentConfig())
        p = generate(f, AgentConfig())
        self.assertEqual(len(p), 24)
        self.assertEqual({v.strategy for v in p}, set(OPTIONS)-{"NO_TRADE"})
        self.assertTrue(all(v.net_edge_bps >= 5 for v in p if v.eligible))
        high_cost = generate(f, AgentConfig(taker_fee_bps=10000))
        self.assertFalse(any(v.eligible for v in high_cost))

    def test_each_policy_has_a_distinct_trigger(self):
        h = histories()
        features, _ = build_features(h, h["pas:BTC"][-1].asof_ms, AgentConfig())
        f = features["pas:BTC"]
        base = {**f, "vol_bps": 50/math.sqrt(60), "risk_bps": 50, "momentum_15_bps": 0,
                "momentum_60_bps": 0, "momentum_3_bps": 0, "spread_bps": 2,
                "zscore": 0, "reversion_bps": 0, "basis_bps": None,
                "funding_rate": None, "squeeze_ratio": 1, "oracle_change_bps": None}
        triggers = {
            "S02": {"momentum_15_bps": 100, "momentum_60_bps": 200, "momentum_3_bps": 10},
            "S03": {"zscore": 2, "reversion_bps": -100},
            "S04": {"basis_bps": 200},
            "S14": {"funding_rate": .03},
            "N01": {"squeeze_ratio": .2, "range_high": base["mid"]*.99,
                    "momentum_15_bps": 100, "momentum_3_bps": 10},
            "N02": {"momentum_15_bps": 200, "momentum_3_bps": -20},
            "N04": {"oracle_change_bps": 100, "momentum_3_bps": 20},
        }
        for strategy, changes in triggers.items():
            p = generate({"pas:BTC": {**base, **changes}}, AgentConfig())
            self.assertTrue(next(v for v in p if v.strategy == strategy).eligible, strategy)
        trio = {s: {**base, "symbol": s, "momentum_60_bps": m}
                for s, m in (("pas:BTC", -200), ("pas:ETH", 0), ("pas:HYPE", 200))}
        legs = [p for p in generate(trio, AgentConfig()) if p.strategy == "N03" and p.eligible]
        self.assertEqual({p.direction for p in legs}, {-1, 1})

    def test_par_adapter_passes_checked_forecast_and_registry(self):
        config = AgentConfig(dex="par")
        observations = synthetic_observations(250, "par")
        steps = {r.symbol: r.quantity_step for r in observations}
        adapter = AgentForecastProducer(config, RuleRouter(), steps)
        registry = ProducerRegistry()
        registry.register(adapter)
        self.assertIs(registry.resolve(adapter.producer_id), adapter)
        datasets = {}
        for request in adapter.requirements():
            datasets[request.dataset_id] = {"source": request.source, "kind": request.kind,
                                            "parameters": {}, "status": "ready", "required": True,
                                            "records": [{"symbol": r.symbol, "event_ms": r.event_ms,
                                                         "received_ms": r.available_ms,
                                                         "data": {"bid": str(r.bid), "ask": str(r.ask),
                                                                  "mark": str(r.mid), "oracle": str(r.oracle)}}
                                                        for r in observations if r.symbol in request.symbols]}
        context = {"protocol_version": "1.0", "context_id": "par-agent-shadow",
                   "asof_ms": observations[-1].asof_ms, "datasets": datasets,
                   "account": None, "execution_reports": []}
        batch = checked_forecast(adapter, context, clock=lambda: context["asof_ms"])
        self.assertEqual(len(batch.items), 3)
        self.assertTrue(adapter.last_analysis["probabilities"])
        with self.assertRaises(ValueError):
            AgentForecastProducer(AgentConfig(), RuleRouter(), {"pas:BTC": .00001})


class AgentRiskAndRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = str(Path(self.tmp.name)/"agent.sqlite3")
        self.config = AgentConfig(epsilon=0)
        self.h = histories()
        self.asof = self.h["pas:BTC"][-1].asof_ms

    def journal(self, binding=None):
        journal = AgentJournal(self.path, binding or {"run": "test"})
        self.addCleanup(journal.close)
        return journal

    def test_atomic_idempotency_and_restart(self):
        j = self.journal()
        harness = AgentHarness(self.config, RuleRouter(), j)
        result = harness.step(self.h, self.asof)
        self.assertEqual(result, harness.step(self.h, self.asof))
        other = self.journal()
        self.assertEqual(result, AgentHarness(self.config, RuleRouter(), other).step(self.h, self.asof))
        changed = copy.deepcopy(self.h)
        changed["pas:BTC"][-1] = replace(changed["pas:BTC"][-1], ask=changed["pas:BTC"][-1].ask+1)
        with self.assertRaises(ValueError):
            harness.step(changed, self.asof)
        with self.assertRaises(ValueError):
            self.journal({"run": "other"})

    def test_new_router_failure_keeps_existing_exit_manager(self):
        j = self.journal()
        state = initial_state(100000)
        symbol = "pas:BTC"
        mid = self.h[symbol][-1].mid
        state["positions"][symbol] = {"quantity": .001, "last_mid": mid, "entry_price": mid,
                                     "opened_ms": 0, "exit_ms": 1, "exploratory": False}
        with j.transaction():
            j.db.execute("INSERT INTO state VALUES(1,?)", (json.dumps(state),))
        router = JevRouter(lambda request: (_ for _ in ()).throw(TimeoutError("secret!")), "test-choice/1")
        result = AgentHarness(self.config, router, j).step(self.h, self.asof)
        self.assertEqual(result["routing"]["error"], "TimeoutError")
        self.assertEqual(result["pending_orders"][symbol]["quantity"], 0)
        self.assertNotIn("secret!", json.dumps(result))

    def test_minimum_order_gross_retained_and_halted(self):
        f = {"pas:BTC": {"mid": 100, "quantity_step": .1}}
        self.assertFalse(review({"pas:BTC": 9}, {}, f, self.config)[0])
        self.assertFalse(review({"pas:BTC": 100}, {}, f, self.config, halted=True)[0])
        retained = {"pas:ETH": {"quantity": 1}}
        self.assertFalse(review({"pas:BTC": 100}, retained, f, self.config)[0])
        existing = {"pas:BTC": {"quantity": 1}}
        self.assertEqual(review({"pas:BTC": 0}, existing, f, self.config, halted=True)[0], {"pas:BTC": 0})

    def test_next_tick_fee_and_execution_recheck(self):
        s = "pas:BTC"
        config = replace(self.config, rebalance_usd=0)
        state = initial_state(100000)
        state["pending"][s] = {"quantity": 1, "created_ms": 1, "expires_ms": 90001,
                                "exploratory": False, "reason": "test"}
        market = {s: {"mid": 100, "bid": 99.99, "ask": 100.01, "quantity_step": .1, "spread_bps": 2}}
        self.assertFalse(fill_pending(state, market, 1, config)[0])
        fills, rejected = fill_pending(state, market, 60001, config)
        self.assertFalse(rejected)
        self.assertEqual(len(fills), 1)
        self.assertAlmostEqual(state["cash"], 100000-(fills[0]["price"]-100)-fills[0]["fee"])
        self.assertAlmostEqual(state["fees"], fills[0]["fee"])

    def test_delayed_funding_uses_settlement_position_not_current_position(self):
        state = initial_state(100000)
        s = "pas:BTC"
        state["position_history"][s] = [{"asof_ms": 0, "quantity": 2}, {"asof_ms": 120000, "quantity": 0}]
        row = Observation(s, 180000, 180000, 180000, 99, 101, .1, 100, 60000, .01, 60000, 180000)
        # An oracle actually observed at the settlement cutoff is required.
        prior = Observation(s, 60000, 60000, 60000, 99, 101, .1, 100, 60000)
        events = mark_and_fund(state, {s: [prior, row]}, {}, 180000)
        self.assertAlmostEqual(state["funding"], -2)
        mark_and_fund(state, {s: [prior, row]}, {}, 180000)
        self.assertAlmostEqual(state["funding"], -2)
        self.assertEqual(events[0]["kind"], "funding")

    def test_exploration_one_draw_durable_and_daily_cap(self):
        p = Proposal("N02", "pas:BTC", 1, 100, 20, 50, 100, 24, True, "test")
        config = replace(self.config, epsilon=1, exploration_max_daily=1)
        state = {}
        candidate, trace = choose([p], self.asof, state, config)
        self.assertEqual(candidate, p)
        self.assertEqual(trace["status"], "selected")
        restored = json.loads(json.dumps(state))
        self.assertIsNone(choose([p], self.asof+60000, restored, config)[0])
        self.assertIsNone(choose([p], self.asof+7200000, restored, config)[0])

    def test_missing_hourly_funding_is_reported(self):
        state = initial_state(100000)
        s = "pas:BTC"
        state["last_ms"] = 3599999
        state["position_history"][s] = [{"asof_ms": 1000, "quantity": 1}]
        mark_and_fund(state, {}, {}, 3600000)
        self.assertFalse(state["funding_coverage_complete"])
        self.assertEqual(state["funding_due"], [s+":3600000"])

    def test_programmatic_harness_cannot_change_policy_on_restart(self):
        j = self.journal()
        AgentHarness(self.config, RuleRouter(), j)
        with self.assertRaises(ValueError):
            AgentHarness(replace(self.config, top_p=.9), RuleRouter(), j)

    def test_no_trade_only_does_not_open_or_explore(self):
        router = JevRouter(lambda request: response(request, distribution(NO_TRADE=1)), "test-choice/1")
        result = AgentHarness(replace(self.config, epsilon=1), router, self.journal()).step(self.h, self.asof)
        self.assertEqual(result["routing"]["selected"], ["NO_TRADE"])
        self.assertFalse(result["pending_orders"])
        self.assertEqual(result["exploration"]["status"], "not-attempted")


class AgentConfigTests(unittest.TestCase):
    def test_config_validation(self):
        self.assertEqual(load_config("config/agent-v1.toml").top_p, .85)
        for kwargs in ({"top_p": 0}, {"epsilon": 2}, {"min_order_usd": 9}, {"seed": True},
                       {"risk_budget_usd": float("nan")}, {"top_k": 2.5}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                AgentConfig(**kwargs)

    def test_default_serialization_is_finite(self):
        json.dumps(asdict(AgentConfig()), allow_nan=False)
        self.assertEqual(len(grouped(synthetic_observations(3))), 3)
        self.assertEqual(make_request(1, {}, [], "id")["asof_ms"], 1)


if __name__ == "__main__":
    unittest.main()
