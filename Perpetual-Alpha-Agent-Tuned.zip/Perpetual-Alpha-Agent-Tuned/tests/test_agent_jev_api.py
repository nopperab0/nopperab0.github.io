"""Official HTTP shapes tested with a fake connection; no external requests or real key."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from perpetual_alpha.agent.jev_api import (
    JevConfig,
    JevConfigurationError,
    JevHTTPError,
    load_config,
    request_choice,
)
from perpetual_alpha.agent.routing import make_request
from perpetual_alpha.agent.strategies import Proposal


class JevAPITests(unittest.TestCase):
    def setUp(self):
        p = Proposal("S02", "pas:BTC", 1, 100, 20, 50, None, 0, True, "test")
        self.request = make_request(1, {}, [p], "snapshot")
        self.config = JevConfig("fake-unit-test-key")
        self.payload = {"model": self.config.model, "answers": {"strategy": {
            "type": "choice", "choice": "S02", "probabilities": {"S02": .8, "NO_TRADE": .2}}}}

    def connection(self, payload=None, *, status=200):
        connection = Mock()
        response = connection.getresponse.return_value
        response.status = status
        response.read1.side_effect = [json.dumps(payload or self.payload).encode(), b""]
        return connection

    def test_http_mapping_full_distribution_version_and_no_key_in_state(self):
        connection = self.connection()
        with patch("perpetual_alpha.agent.jev_api.http.client.HTTPSConnection", return_value=connection) as factory:
            result = request_choice(self.request, config=self.config)
        factory.assert_called_once_with("api.typesafe.ai", timeout=1.8)
        method, path, body, headers = connection.request.call_args.args
        self.assertEqual((method, path), ("POST", "/v1/systemone"))
        self.assertEqual(headers["Authorization"], "Bearer fake-unit-test-key")
        payload = json.loads(body)
        self.assertEqual(payload["questions"]["strategy"]["criteria"], self.request["options"])
        self.assertEqual(payload["model"], "jev-1.14.0")
        self.assertNotIn(self.config.api_key, body.decode())
        self.assertNotIn(self.config.api_key, repr(self.config))
        self.assertEqual(result["probabilities"], {"S02": .8, "NO_TRADE": .2})
        self.assertEqual(result["request_id"], self.request["request_id"])
        connection.close.assert_called_once()

    def test_redirects_auth_errors_and_rate_limits_do_not_retry(self):
        for status in (302, 401, 429, 500):
            with self.subTest(status=status):
                connection = self.connection(status=status)
                with patch("perpetual_alpha.agent.jev_api.http.client.HTTPSConnection", return_value=connection):
                    with self.assertRaises(JevHTTPError):
                        request_choice(self.request, config=self.config)
                connection.request.assert_called_once()
                connection.close.assert_called_once()

    def test_changed_model_and_extra_or_missing_options_fail(self):
        wrong_model = {**self.payload, "model": "jev-1.13.0"}
        for payload in (wrong_model, {"model": self.config.model, "answers": {"strategy": {
                "type": "choice", "choice": "S02", "probabilities": {"S02": .8, "NO_TRADE": .2, "N04": 0}}}}):
            connection = self.connection(payload)
            with patch("perpetual_alpha.agent.jev_api.http.client.HTTPSConnection", return_value=connection):
                with self.assertRaises(ValueError):
                    request_choice(self.request, config=self.config)

    def test_duplicate_json_and_nonfinite_probability_fail(self):
        for raw in (b'{"model":"a","model":"b"}',
                    json.dumps({**self.payload, "extra": float("nan")}).encode()):
            connection = self.connection()
            connection.getresponse.return_value.read1.side_effect = [raw, b""]
            with patch("perpetual_alpha.agent.jev_api.http.client.HTTPSConnection", return_value=connection):
                with self.assertRaises(ValueError):
                    request_choice(self.request, config=self.config)

    def test_total_receive_deadline_and_size_limit(self):
        connection = self.connection()
        with patch("perpetual_alpha.agent.jev_api.http.client.HTTPSConnection", return_value=connection), \
                patch("perpetual_alpha.agent.jev_api.time.monotonic", side_effect=[0, 2]):
            with self.assertRaises(TimeoutError):
                request_choice(self.request, config=self.config)
        connection = self.connection()
        connection.getresponse.return_value.read1.side_effect = [b"x"*65537]
        with patch("perpetual_alpha.agent.jev_api.http.client.HTTPSConnection", return_value=connection):
            with self.assertRaises(ValueError):
                request_choice(self.request, config=self.config)

    def test_environment_config_and_blank_key_fail_before_network(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict("os.environ", {}, clear=True):
            path = Path(directory)/".env.jev"
            path.write_text("TYPESAFE_API_KEY=\nJEV_MODEL=jev-1.14.0\n", encoding="utf-8")
            with self.assertRaises(JevConfigurationError):
                load_config(path)
            path.write_text("TYPESAFE_API_KEY='fake-key'\nJEV_MODEL=jev-1.14.0\n", encoding="utf-8")
            self.assertEqual(load_config(path).api_key, "fake-key")
            with patch.dict("os.environ", {"TYPESAFE_API_KEY": "override-key"}):
                self.assertEqual(load_config(path).api_key, "override-key")
        for key, model in (("", "jev-1.14.0"), ("x\ny", "jev-1.14.0"), ("key", "jev-latest")):
            with self.assertRaises(JevConfigurationError):
                JevConfig(key, model)


if __name__ == "__main__":
    unittest.main()
